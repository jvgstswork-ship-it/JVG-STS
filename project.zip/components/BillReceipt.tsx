import { StyleSheet, Text, View } from 'react-native';
import type { Bill } from '@/store/shop';
import { shop } from '@/constants/shop';
import { colors } from '@/constants/theme';
import { formatDate, formatINR, formatTime } from '@/utils/format';

const paymentLabels: Record<Bill['paymentMode'], string> = {
  cash: 'नकद',
  upi: 'UPI',
  udhaar: 'उधार',
};

export function BillReceipt({ bill }: { bill: Bill }) {
  return (
    <View style={styles.receipt}>
      <View pointerEvents="none" style={styles.watermarkLayer}>
        <Text style={[styles.watermark, styles.watermarkTop]}>JVG STS</Text>
        <Text style={[styles.watermark, styles.watermarkMid]}>JVG STS</Text>
        <Text style={[styles.watermark, styles.watermarkLow]}>JVG STS</Text>
      </View>

      <View style={styles.brandRow}>
        <View style={styles.logo}>
          <Text style={styles.logoText}>JVG</Text>
        </View>
        <View style={styles.brandText}>
          <Text style={styles.shopName}>{shop.name}</Text>
          <Text style={styles.tagline}>{shop.tagline}</Text>
        </View>
      </View>

      <View style={styles.metaRow}>
        <View>
          <Text style={styles.metaLabel}>बिल नंबर</Text>
          <Text style={styles.metaValue}>{bill.number}</Text>
        </View>
        <View style={styles.metaRight}>
          <Text style={styles.metaLabel}>दिनांक</Text>
          <Text style={styles.metaValue}>
            {formatDate(bill.createdAt)}, {formatTime(bill.createdAt)}
          </Text>
        </View>
      </View>

      <View style={styles.customerBox}>
        <Text style={styles.customerName}>{bill.customerName}</Text>
        {bill.customerPhone ? (
          <Text style={styles.customerPhone}>मोबाइल: {bill.customerPhone}</Text>
        ) : null}
        <Text style={styles.customerPhone}>बिल बनाने वाला: {bill.staffName}</Text>
      </View>

      <View style={styles.dashed} />

      <View style={styles.tableHeader}>
        <Text style={styles.tableHeaderItem}>सामान</Text>
        <Text style={styles.tableHeaderAmount}>रकम</Text>
      </View>

      {bill.items.map((item, index) => (
        <View
          key={`${item.productId}-${index}`}
          style={[styles.itemRow, index % 2 === 1 && styles.itemRowAlt]}
        >
          <View style={styles.itemMain}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text style={styles.itemMeta}>
              {item.qty} × {formatINR(item.price)}
            </Text>
          </View>
          <Text style={styles.itemAmount}>{formatINR(item.price * item.qty)}</Text>
        </View>
      ))}

      <View style={styles.dashed} />

      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>सब-टोटल</Text>
        <Text style={styles.totalValue}>{formatINR(bill.subtotal)}</Text>
      </View>
      {bill.discount > 0 ? (
        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>छूट</Text>
          <Text style={styles.totalValue}>− {formatINR(bill.discount)}</Text>
        </View>
      ) : null}
      <View style={styles.grandRow}>
        <Text style={styles.grandLabel}>कुल राशि</Text>
        <Text style={styles.grandValue}>{formatINR(bill.total)}</Text>
      </View>

      <View style={styles.paymentRow}>
        <Text style={styles.paymentLabel}>भुगतान</Text>
        <Text style={styles.paymentValue}>
          {paymentLabels[bill.paymentMode]}
          {bill.paymentMode === 'udhaar' && !bill.settled ? ' (बाकी)' : ' — प्राप्त'}
        </Text>
      </View>

      <View style={styles.thankBox}>
        <Text style={styles.thankText}>धन्यवाद! दोबारा आइए।</Text>
        <Text style={styles.blessing}>
          आशीर्वाद: आपका परिवार सुखी रहे और व्यापार दिन-दूनी रात-चौगुनी बढ़े।
        </Text>
        <Text style={styles.shopContact}>
          {shop.phone} · {shop.address}
        </Text>
        <Text style={styles.brandMark}>JVG STS · JVG SmartTech Suvidha</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  receipt: {
    width: 320,
    backgroundColor: '#ffffff',
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: '#e8e3d7',
    overflow: 'hidden',
  },
  watermarkLayer: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 0,
  },
  watermark: {
    position: 'absolute',
    alignSelf: 'center',
    fontSize: 46,
    fontWeight: '800',
    letterSpacing: 3,
    color: '#12372a',
    opacity: 0.09,
    transform: [{ rotate: '-24deg' }],
  },
  watermarkTop: {
    top: 92,
    left: -18,
  },
  watermarkMid: {
    top: 236,
    left: 8,
  },
  watermarkLow: {
    top: 396,
    left: -18,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  logo: {
    width: 44,
    height: 44,
    borderRadius: 13,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#ffffff',
    letterSpacing: 0.5,
  },
  brandText: {
    flex: 1,
  },
  shopName: {
    fontSize: 15,
    fontWeight: '800',
    color: '#14251d',
  },
  tagline: {
    fontSize: 9.5,
    color: '#708077',
    marginTop: 1,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 14,
    gap: 8,
  },
  metaRight: {
    alignItems: 'flex-end',
  },
  metaLabel: {
    fontSize: 8.5,
    color: '#8d9a93',
    fontWeight: '600',
  },
  metaValue: {
    fontSize: 10.5,
    fontWeight: '700',
    color: '#14251d',
    marginTop: 1,
  },
  customerBox: {
    backgroundColor: '#f7f5ee',
    borderRadius: 9,
    padding: 10,
    marginTop: 10,
    gap: 2,
  },
  customerName: {
    fontSize: 12,
    fontWeight: '800',
    color: '#14251d',
  },
  customerPhone: {
    fontSize: 9.5,
    color: '#708077',
  },
  dashed: {
    borderBottomWidth: 1,
    borderStyle: 'dashed',
    borderBottomColor: '#d8d2c4',
    marginVertical: 12,
  },
  tableHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  tableHeaderItem: {
    fontSize: 8.5,
    fontWeight: '800',
    color: '#8d9a93',
    letterSpacing: 0.4,
  },
  tableHeaderAmount: {
    fontSize: 8.5,
    fontWeight: '800',
    color: '#8d9a93',
    letterSpacing: 0.4,
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingVertical: 6,
    gap: 10,
  },
  itemRowAlt: {
    backgroundColor: '#faf8f2',
  },
  itemMain: {
    flex: 1,
  },
  itemName: {
    fontSize: 10.5,
    fontWeight: '600',
    color: '#14251d',
  },
  itemMeta: {
    fontSize: 8.5,
    color: '#8d9a93',
    marginTop: 1,
  },
  itemAmount: {
    fontSize: 10.5,
    fontWeight: '700',
    color: '#14251d',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 3,
  },
  totalLabel: {
    fontSize: 10,
    color: '#708077',
  },
  totalValue: {
    fontSize: 10,
    fontWeight: '600',
    color: '#14251d',
  },
  grandRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#e2ece5',
    borderRadius: 9,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginTop: 5,
  },
  grandLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: '#12372a',
  },
  grandValue: {
    fontSize: 15,
    fontWeight: '800',
    color: '#12372a',
  },
  paymentRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 9,
  },
  paymentLabel: {
    fontSize: 9.5,
    color: '#708077',
  },
  paymentValue: {
    fontSize: 9.5,
    fontWeight: '700',
    color: '#14251d',
  },
  thankBox: {
    alignItems: 'center',
    marginTop: 14,
    gap: 2,
  },
  thankText: {
    fontSize: 11,
    fontWeight: '800',
    color: '#12372a',
  },
  blessing: {
    fontSize: 8.5,
    fontWeight: '700',
    color: '#8a5a12',
    textAlign: 'center',
    marginTop: 2,
    lineHeight: 12,
  },
  shopContact: {
    fontSize: 8,
    color: '#8d9a93',
    textAlign: 'center',
  },
  brandMark: {
    fontSize: 7.5,
    fontWeight: '800',
    letterSpacing: 0.6,
    color: '#12372a',
    marginTop: 2,
  },
});
