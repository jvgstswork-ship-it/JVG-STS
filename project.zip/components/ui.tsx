import React, { type ReactNode } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { Minus, Plus } from 'lucide-react-native';
import { colors, glass, radius, shadow } from '@/constants/theme';

type CardProps = {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
};

export function Card({ children, style }: CardProps) {
  return <View style={[styles.card, style]}>{children}</View>;
}

type SectionHeaderProps = {
  title: string;
  caption?: string;
  action?: string;
  onAction?: () => void;
};

export function SectionHeader({ title, caption, action, onAction }: SectionHeaderProps) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionTitleWrap}>
        <Text style={styles.sectionTitle}>{title}</Text>
        {caption ? <Text style={styles.sectionCaption}>{caption}</Text> : null}
      </View>
      {action && onAction ? (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={styles.sectionAction}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

type ChipProps = {
  label: string;
  active?: boolean;
  onPress?: () => void;
};

export function Chip({ label, active, onPress }: ChipProps) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.chip, active && styles.chipActive]}
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
    >
      <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
    </Pressable>
  );
}

export type BadgeTone = 'brand' | 'accent' | 'danger' | 'info' | 'muted';

const badgeColors: Record<BadgeTone, { bg: string; text: string }> = {
  brand: { bg: colors.brandSoft, text: colors.brand },
  accent: { bg: colors.accentSoft, text: '#8a5a12' },
  danger: { bg: colors.dangerSoft, text: colors.danger },
  info: { bg: colors.infoSoft, text: colors.info },
  muted: { bg: '#f0eee7', text: colors.muted },
};

export function Badge({ label, tone = 'muted' }: { label: string; tone?: BadgeTone }) {
  const palette = badgeColors[tone];
  return (
    <View style={[styles.badge, { backgroundColor: palette.bg }]}>
      <Text style={[styles.badgeText, { color: palette.text }]}>{label}</Text>
    </View>
  );
}

type ButtonTone = 'primary' | 'accent' | 'danger' | 'ghost';

type PrimaryButtonProps = {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  tone?: ButtonTone;
  icon?: ReactNode;
  style?: StyleProp<ViewStyle>;
};

export function PrimaryButton({
  label,
  onPress,
  disabled,
  loading,
  tone = 'primary',
  icon,
  style,
}: PrimaryButtonProps) {
  const isGhost = tone === 'ghost';
  const background =
    tone === 'accent'
      ? colors.accent
      : tone === 'danger'
        ? colors.danger
        : tone === 'ghost'
          ? 'transparent'
          : colors.brand;
  const textColor = isGhost ? colors.brand : colors.white;

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: background },
        isGhost && styles.buttonGhost,
        (disabled || loading) && styles.buttonDisabled,
        pressed && !disabled && !loading && styles.buttonPressed,
        style,
      ]}
      accessibilityRole="button"
    >
      {loading ? (
        <ActivityIndicator color={textColor} size="small" />
      ) : (
        <>
          {icon}
          <Text style={[styles.buttonText, { color: textColor }]}>{label}</Text>
        </>
      )}
    </Pressable>
  );
}

type FieldProps = TextInputProps & {
  label: string;
  hint?: string;
  error?: string;
  containerStyle?: StyleProp<ViewStyle>;
};

export function Field({ label, hint, error, containerStyle, ...inputProps }: FieldProps) {
  return (
    <View style={[styles.fieldWrap, containerStyle]}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        placeholderTextColor={colors.soft}
        style={[styles.input, error ? styles.inputError : null]}
        {...inputProps}
      />
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      {!error && hint ? <Text style={styles.hintText}>{hint}</Text> : null}
    </View>
  );
}

type EmptyStateProps = {
  icon: ReactNode;
  title: string;
  body: string;
};

export function EmptyState({ icon, title, body }: EmptyStateProps) {
  return (
    <View style={styles.empty}>
      <View style={styles.emptyIcon}>{icon}</View>
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyBody}>{body}</Text>
    </View>
  );
}

type QtyStepperProps = {
  value: number;
  onDecrease: () => void;
  onIncrease: () => void;
  size?: 'sm' | 'md';
};

export function QtyStepper({ value, onDecrease, onIncrease, size = 'md' }: QtyStepperProps) {
  const compact = size === 'sm';
  return (
    <View style={[styles.stepper, compact && styles.stepperSm]}>
      <Pressable
        onPress={onDecrease}
        style={[styles.stepperButton, compact && styles.stepperButtonSm]}
        accessibilityLabel="मात्रा घटाएं"
      >
        <Minus size={compact ? 14 : 16} color={colors.brand} />
      </Pressable>
      <Text style={[styles.stepperValue, compact && styles.stepperValueSm]}>{value}</Text>
      <Pressable
        onPress={onIncrease}
        style={[styles.stepperButton, compact && styles.stepperButtonSm]}
        accessibilityLabel="मात्रा बढ़ाएं"
      >
        <Plus size={compact ? 14 : 16} color={colors.brand} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: glass.fill,
    borderRadius: radius.lg,
    padding: 16,
    borderWidth: 1,
    borderColor: glass.border,
    ...shadow,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginBottom: 12,
    gap: 12,
  },
  sectionTitleWrap: {
    flex: 1,
    gap: 3,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.2,
  },
  sectionCaption: {
    fontSize: 12,
    color: colors.muted,
  },
  sectionAction: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.brandMid,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
  },
  chipActive: {
    backgroundColor: colors.brand,
    borderColor: colors.brand,
  },
  chipText: {
    fontSize: 12.5,
    fontWeight: '600',
    color: colors.muted,
  },
  chipTextActive: {
    color: colors.white,
  },
  badge: {
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  badgeText: {
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  button: {
    minHeight: 50,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 18,
  },
  buttonGhost: {
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.fillStrong,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonPressed: {
    opacity: 0.88,
    transform: [{ scale: 0.995 }],
  },
  buttonText: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.1,
  },
  fieldWrap: {
    gap: 6,
  },
  fieldLabel: {
    fontSize: 12.5,
    fontWeight: '700',
    color: colors.ink,
  },
  input: {
    minHeight: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.input,
    paddingHorizontal: 14,
    fontSize: 15,
    color: colors.ink,
  },
  inputError: {
    borderColor: colors.danger,
    backgroundColor: '#fffafa',
  },
  errorText: {
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.danger,
  },
  hintText: {
    fontSize: 11.5,
    color: colors.muted,
  },
  empty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 34,
    paddingHorizontal: 18,
    gap: 8,
  },
  emptyIcon: {
    width: 58,
    height: 58,
    borderRadius: 20,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  emptyTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
    textAlign: 'center',
  },
  emptyBody: {
    fontSize: 12.5,
    color: colors.muted,
    textAlign: 'center',
    lineHeight: 18,
    maxWidth: 260,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: glass.fillStrong,
    borderRadius: 999,
    padding: 3,
    gap: 2,
  },
  stepperSm: {
    padding: 2,
  },
  stepperButton: {
    width: 30,
    height: 30,
    borderRadius: 999,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepperButtonSm: {
    width: 25,
    height: 25,
  },
  stepperValue: {
    minWidth: 26,
    textAlign: 'center',
    fontSize: 14,
    fontWeight: '800',
    color: colors.brand,
  },
  stepperValueSm: {
    minWidth: 22,
    fontSize: 12.5,
  },
});
