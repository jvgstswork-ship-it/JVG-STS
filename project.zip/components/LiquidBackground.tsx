import { StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export function LiquidBackground() {
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <LinearGradient
        colors={['#e4f0e8', '#f7f2e4', '#e4edf5']}
        locations={[0, 0.55, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.blob, styles.blobAmber]} />
      <View style={[styles.blob, styles.blobGreen]} />
      <View style={[styles.blob, styles.blobBlue]} />
    </View>
  );
}

const styles = StyleSheet.create({
  blob: {
    position: 'absolute',
    borderRadius: 999,
  },
  blobAmber: {
    width: 300,
    height: 300,
    top: -110,
    right: -120,
    backgroundColor: 'rgba(230, 162, 60, 0.22)',
  },
  blobGreen: {
    width: 280,
    height: 280,
    bottom: 40,
    left: -140,
    backgroundColor: 'rgba(29, 84, 64, 0.16)',
  },
  blobBlue: {
    width: 240,
    height: 240,
    top: '38%',
    right: -100,
    backgroundColor: 'rgba(76, 132, 168, 0.14)',
  },
});
