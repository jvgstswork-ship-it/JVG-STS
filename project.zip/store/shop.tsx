import AsyncStorage from '@react-native-async-storage/async-storage';
import { shop } from '@/constants/shop';
import { dateKey } from '@/utils/attendance';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';

export type PaymentMode = 'cash' | 'upi' | 'udhaar';

export type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  unit: string;
  updatedAt: string;
};

export type BillItem = {
  productId: string;
  name: string;
  price: number;
  qty: number;
  unit: string;
};

export type Bill = {
  id: string;
  number: string;
  customerName: string;
  customerPhone: string;
  items: BillItem[];
  subtotal: number;
  discount: number;
  total: number;
  paymentMode: PaymentMode;
  settled: boolean;
  staffId: string;
  staffName: string;
  createdAt: string;
};

export type StaffMember = {
  id: string;
  name: string;
  role: string;
  phone: string;
  salary: number;
  notes: string;
  present: boolean;
  joinedAt: string;
};

type NewBillInput = {
  items: BillItem[];
  customerName: string;
  customerPhone: string;
  discount: number;
  paymentMode: PaymentMode;
  staffId: string;
  staffName: string;
};

export type AttendanceMap = Record<string, Record<string, boolean>>;

type NewProductInput = {
  name: string;
  category: string;
  price: number;
  stock: number;
  unit: string;
};

type NewStaffInput = {
  name: string;
  role: string;
  phone: string;
  salary: number;
  notes: string;
};

type ShopContextValue = {
  ready: boolean;
  products: Product[];
  bills: Bill[];
  staff: StaffMember[];
  attendance: AttendanceMap;
  upiId: string;
  setUpiId: (value: string) => void;
  addProduct: (input: NewProductInput) => void;
  updateStock: (id: string, delta: number) => void;
  deleteProduct: (id: string) => void;
  addBill: (input: NewBillInput) => Bill;
  settleBill: (id: string) => void;
  deleteBill: (id: string) => void;
  addStaff: (input: NewStaffInput) => void;
  updateStaff: (id: string, input: NewStaffInput) => void;
  markAttendance: (id: string, present: boolean, key?: string) => void;
  deleteStaff: (id: string) => void;
};

const STORAGE_KEY = 'jvg-smarttech-suvidha-v4';

function hoursAgo(hours: number): string {
  return new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();
}

const seedProducts: Product[] = [
  {
    id: 'p1',
    name: '32 इंच LED टीवी',
    category: 'टीवी',
    price: 12999,
    stock: 4,
    unit: 'पीस',
    updatedAt: hoursAgo(2),
  },
  {
    id: 'p2',
    name: '43 इंच स्मार्ट टीवी',
    category: 'टीवी',
    price: 24999,
    stock: 2,
    unit: 'पीस',
    updatedAt: hoursAgo(4),
  },
  {
    id: 'p3',
    name: 'सिंगल डोर फ्रिज 190L',
    category: 'फ्रिज',
    price: 18999,
    stock: 3,
    unit: 'पीस',
    updatedAt: hoursAgo(6),
  },
  {
    id: 'p4',
    name: 'डबल डोर फ्रिज 260L',
    category: 'फ्रिज',
    price: 28999,
    stock: 2,
    unit: 'पीस',
    updatedAt: hoursAgo(8),
  },
  {
    id: 'p5',
    name: 'फ्रंट लोड वॉशिंग मशीन',
    category: 'वॉशिंग मशीन',
    price: 21999,
    stock: 2,
    unit: 'पीस',
    updatedAt: hoursAgo(10),
  },
  {
    id: 'p6',
    name: '1.5 टन स्प्लिट AC',
    category: 'AC',
    price: 32999,
    stock: 1,
    unit: 'पीस',
    updatedAt: hoursAgo(12),
  },
  {
    id: 'p7',
    name: 'सीलिंग फैन',
    category: 'फैन',
    price: 1499,
    stock: 15,
    unit: 'पीस',
    updatedAt: hoursAgo(14),
  },
  {
    id: 'p8',
    name: 'मिक्सर ग्राइंडर',
    category: 'स्माल एप्लायंसेज',
    price: 2499,
    stock: 8,
    unit: 'पीस',
    updatedAt: hoursAgo(16),
  },
  {
    id: 'p9',
    name: 'प्रेस आयरन',
    category: 'स्माल एप्लायंसेज',
    price: 999,
    stock: 10,
    unit: 'पीस',
    updatedAt: hoursAgo(18),
  },
  {
    id: 'p10',
    name: '9W LED बल्ब',
    category: 'स्माल एप्लायंसेज',
    price: 199,
    stock: 40,
    unit: 'पीस',
    updatedAt: hoursAgo(20),
  },
  {
    id: 'p11',
    name: 'एक्सटेंशन बोर्ड',
    category: 'स्माल एप्लायंसेज',
    price: 349,
    stock: 12,
    unit: 'पीस',
    updatedAt: hoursAgo(22),
  },
  {
    id: 'p12',
    name: 'Type-C डेटा केबल',
    category: 'मोबाइल एक्सेसरीज़',
    price: 199,
    stock: 26,
    unit: 'पीस',
    updatedAt: hoursAgo(24),
  },
  {
    id: 'p13',
    name: 'boAt Airdopes ईयरबड्स',
    category: 'मोबाइल एक्सेसरीज़',
    price: 1299,
    stock: 8,
    unit: 'पीस',
    updatedAt: hoursAgo(26),
  },
  {
    id: 'p14',
    name: '10000mAh पावर बैंक',
    category: 'मोबाइल एक्सेसरीज़',
    price: 1499,
    stock: 5,
    unit: 'पीस',
    updatedAt: hoursAgo(28),
  },
  {
    id: 'p15',
    name: 'आधार अपडेट सेवा',
    category: 'बैंकिंग सेवा',
    price: 100,
    stock: 99,
    unit: 'सेवा',
    updatedAt: hoursAgo(30),
  },
  {
    id: 'p16',
    name: 'मोबाइल रिचार्ज',
    category: 'बैंकिंग सेवा',
    price: 199,
    stock: 99,
    unit: 'सेवा',
    updatedAt: hoursAgo(32),
  },
  {
    id: 'p17',
    name: 'गेहूं का आटा 5 किलो',
    category: 'किराना',
    price: 240,
    stock: 18,
    unit: 'पैकेट',
    updatedAt: hoursAgo(1),
  },
  {
    id: 'p18',
    name: 'बासमती चावल 5 किलो',
    category: 'किराना',
    price: 520,
    stock: 12,
    unit: 'पैकेट',
    updatedAt: hoursAgo(3),
  },
  {
    id: 'p19',
    name: 'तूर दाल 1 किलो',
    category: 'किराना',
    price: 165,
    stock: 22,
    unit: 'किलो',
    updatedAt: hoursAgo(5),
  },
  {
    id: 'p20',
    name: 'सरसों तेल 1 लीटर',
    category: 'किराना',
    price: 185,
    stock: 16,
    unit: 'बोतल',
    updatedAt: hoursAgo(7),
  },
  {
    id: 'p21',
    name: 'चीनी 1 किलो',
    category: 'किराना',
    price: 48,
    stock: 30,
    unit: 'किलो',
    updatedAt: hoursAgo(9),
  },
  {
    id: 'p22',
    name: 'चायपत्ती 250 ग्राम',
    category: 'किराना',
    price: 130,
    stock: 24,
    unit: 'पैकेट',
    updatedAt: hoursAgo(11),
  },
  {
    id: 'p23',
    name: 'गरम मसाला 100 ग्राम',
    category: 'किराना',
    price: 75,
    stock: 20,
    unit: 'पैकेट',
    updatedAt: hoursAgo(13),
  },
  {
    id: 'p24',
    name: 'दूध 500 मिली',
    category: 'डेयरी',
    price: 30,
    stock: 26,
    unit: 'पैकेट',
    updatedAt: hoursAgo(1.5),
  },
  {
    id: 'p25',
    name: 'दही 400 ग्राम',
    category: 'डेयरी',
    price: 45,
    stock: 14,
    unit: 'पैकेट',
    updatedAt: hoursAgo(2.5),
  },
  {
    id: 'p26',
    name: 'बटर 100 ग्राम',
    category: 'डेयरी',
    price: 62,
    stock: 10,
    unit: 'पैकेट',
    updatedAt: hoursAgo(4.5),
  },
  {
    id: 'p27',
    name: 'मैगी नूडल्स',
    category: 'स्नैक्स',
    price: 14,
    stock: 36,
    unit: 'पैकेट',
    updatedAt: hoursAgo(6.5),
  },
  {
    id: 'p28',
    name: 'ग्लूकोज़ बिस्किट',
    category: 'स्नैक्स',
    price: 30,
    stock: 28,
    unit: 'पैकेट',
    updatedAt: hoursAgo(8.5),
  },
  {
    id: 'p29',
    name: 'आलू चिप्स',
    category: 'स्नैक्स',
    price: 20,
    stock: 32,
    unit: 'पैकेट',
    updatedAt: hoursAgo(10.5),
  },
  {
    id: 'p30',
    name: 'डिटर्जेंट पाउडर 1 किलो',
    category: 'घरेलू',
    price: 120,
    stock: 15,
    unit: 'पैकेट',
    updatedAt: hoursAgo(12.5),
  },
  {
    id: 'p31',
    name: 'साबुन (4 की पैक)',
    category: 'घरेलू',
    price: 96,
    stock: 18,
    unit: 'पैक',
    updatedAt: hoursAgo(14.5),
  },
  {
    id: 'p32',
    name: 'शैम्पू 180 मिली',
    category: 'व्यक्तिगत देखभाल',
    price: 145,
    stock: 12,
    unit: 'बोतल',
    updatedAt: hoursAgo(16.5),
  },
  {
    id: 'p33',
    name: 'टूथपेस्ट 100 ग्राम',
    category: 'व्यक्तिगत देखभाल',
    price: 65,
    stock: 20,
    unit: 'पैकेट',
    updatedAt: hoursAgo(18.5),
  },
];

const seedBills: Bill[] = [
  {
    id: 'b6',
    number: 'JVG-1006',
    customerName: 'कविता देवी',
    customerPhone: '9811022114',
    items: [
      {
        productId: 'p10',
        name: '9W LED बल्ब',
        price: 199,
        qty: 2,
        unit: 'पीस',
      },
      {
        productId: 'p11',
        name: 'एक्सटेंशन बोर्ड',
        price: 349,
        qty: 1,
        unit: 'पीस',
      },
    ],
    subtotal: 747,
    discount: 47,
    total: 700,
    paymentMode: 'cash',
    settled: true,
    staffId: 's1',
    staffName: 'रमेश कुमार',
    createdAt: hoursAgo(0.5),
  },
  {
    id: 'b5',
    number: 'JVG-1005',
    customerName: 'राकेश वर्मा',
    customerPhone: '9930144520',
    items: [
      {
        productId: 'p1',
        name: '32 इंच LED टीवी',
        price: 12999,
        qty: 1,
        unit: 'पीस',
      },
      {
        productId: 'p7',
        name: 'सीलिंग फैन',
        price: 1499,
        qty: 1,
        unit: 'पीस',
      },
    ],
    subtotal: 14498,
    discount: 498,
    total: 14000,
    paymentMode: 'upi',
    settled: true,
    staffId: 's2',
    staffName: 'सुनीता देवी',
    createdAt: hoursAgo(2),
  },
  {
    id: 'b4',
    number: 'JVG-1004',
    customerName: 'प्रिया शर्मा',
    customerPhone: '9718066502',
    items: [
      {
        productId: 'p15',
        name: 'आधार अपडेट सेवा',
        price: 100,
        qty: 1,
        unit: 'सेवा',
      },
      {
        productId: 'p16',
        name: 'मोबाइल रिचार्ज',
        price: 199,
        qty: 1,
        unit: 'सेवा',
      },
    ],
    subtotal: 299,
    discount: 0,
    total: 299,
    paymentMode: 'upi',
    settled: true,
    staffId: 's1',
    staffName: 'रमेश कुमार',
    createdAt: hoursAgo(3),
  },
  {
    id: 'b3',
    number: 'JVG-1003',
    customerName: 'मोहन लाल',
    customerPhone: '9871230891',
    items: [
      {
        productId: 'p8',
        name: 'मिक्सर ग्राइंडर',
        price: 2499,
        qty: 1,
        unit: 'पीस',
      },
      {
        productId: 'p9',
        name: 'प्रेस आयरन',
        price: 999,
        qty: 1,
        unit: 'पीस',
      },
    ],
    subtotal: 3498,
    discount: 98,
    total: 3400,
    paymentMode: 'udhaar',
    settled: false,
    staffId: 's1',
    staffName: 'रमेश कुमार',
    createdAt: hoursAgo(27),
  },
  {
    id: 'b2',
    number: 'JVG-1002',
    customerName: 'सुमन गुप्ता',
    customerPhone: '9899971245',
    items: [
      {
        productId: 'p14',
        name: '10000mAh पावर बैंक',
        price: 1499,
        qty: 1,
        unit: 'पीस',
      },
      {
        productId: 'p13',
        name: 'boAt Airdopes ईयरबड्स',
        price: 1299,
        qty: 1,
        unit: 'पीस',
      },
    ],
    subtotal: 2798,
    discount: 98,
    total: 2700,
    paymentMode: 'udhaar',
    settled: false,
    staffId: 's2',
    staffName: 'सुनीता देवी',
    createdAt: hoursAgo(30),
  },
  {
    id: 'b1',
    number: 'JVG-1001',
    customerName: 'अनिल यादव',
    customerPhone: '9911850276',
    items: [
      {
        productId: 'p3',
        name: 'सिंगल डोर फ्रिज 190L',
        price: 18999,
        qty: 1,
        unit: 'पीस',
      },
      {
        productId: 'p11',
        name: 'एक्सटेंशन बोर्ड',
        price: 349,
        qty: 1,
        unit: 'पीस',
      },
    ],
    subtotal: 19348,
    discount: 348,
    total: 19000,
    paymentMode: 'cash',
    settled: true,
    staffId: 'owner',
    staffName: 'मालिक',
    createdAt: hoursAgo(50),
  },
];

const seedStaff: StaffMember[] = [
  {
    id: 's1',
    name: 'रमेश कुमार',
    role: 'बैंकिंग ऑपरेटर',
    phone: '9876543210',
    salary: 14000,
    notes: 'आधार और पैन कॉपी फाइल में जमा है। काउंटर 1 संभालते हैं।',
    present: true,
    joinedAt: hoursAgo(24 * 300),
  },
  {
    id: 's2',
    name: 'सुनीता देवी',
    role: 'कैशियर',
    phone: '9123456780',
    salary: 15000,
    notes: 'रोज़ की कैश काउंटिंग और UPI रिकॉर्ड देखती हैं।',
    present: true,
    joinedAt: hoursAgo(24 * 420),
  },
  {
    id: 's3',
    name: 'अर्जुन सिंह',
    role: 'सेल्स एक्ज़ीक्यूटिव',
    phone: '9988766554',
    salary: 11000,
    notes: 'एक्सेसरीज़ डिस्प्ले और स्टॉक रख-रखाव का काम।',
    present: false,
    joinedAt: hoursAgo(24 * 120),
  },
];

function buildSeedAttendance(): AttendanceMap {
  const map: AttendanceMap = { s1: {}, s2: {}, s3: {} };
  const today = new Date();

  for (let offset = 0; offset < 60; offset += 1) {
    const day = new Date(today);
    day.setDate(today.getDate() - offset);
    const key = dateKey(day);
    const sunday = day.getDay() === 0;
    map.s1[key] = !sunday && (offset + 1) % 11 !== 0;
    map.s2[key] = !sunday && (offset + 4) % 13 !== 0;
    map.s3[key] = !sunday && (offset + 2) % 7 !== 0;
  }

  const todayKey = dateKey(today);
  map.s1[todayKey] = true;
  map.s2[todayKey] = true;
  map.s3[todayKey] = false;
  return map;
}

const seedAttendance = buildSeedAttendance();

const ShopContext = createContext<ShopContextValue | null>(null);

type StoredState = {
  products: Product[];
  bills: Bill[];
  staff: StaffMember[];
  attendance: AttendanceMap;
  upiId: string;
};

export function ShopProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [products, setProducts] = useState<Product[]>(seedProducts);
  const [bills, setBills] = useState<Bill[]>(seedBills);
  const [staff, setStaff] = useState<StaffMember[]>(seedStaff);
  const [attendance, setAttendance] = useState<AttendanceMap>(seedAttendance);
  const [upiId, setUpiIdState] = useState(shop.upiId);

  useEffect(() => {
    let alive = true;

    async function load() {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw && alive) {
          const parsed = JSON.parse(raw) as Partial<StoredState>;
          if (Array.isArray(parsed.products)) setProducts(parsed.products);
          if (Array.isArray(parsed.bills)) setBills(parsed.bills);
          if (Array.isArray(parsed.staff)) setStaff(parsed.staff);
          if (parsed.attendance && typeof parsed.attendance === 'object') {
            setAttendance(parsed.attendance);
          }
          if (typeof parsed.upiId === 'string' && parsed.upiId.includes('@')) {
            setUpiIdState(parsed.upiId);
          }
        }
      } catch {
        // Local data is optional; fall back to the seeded shop.
      } finally {
        if (alive) setReady(true);
      }
    }

    load();

    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const state: StoredState = { products, bills, staff, attendance, upiId };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => {
      // Saving is best-effort; the session still works in memory.
    });
  }, [ready, products, bills, staff, attendance, upiId]);

  const setUpiId = useCallback((value: string) => {
    setUpiIdState(value.trim());
  }, []);

  const addProduct = useCallback((input: NewProductInput) => {
    const product: Product = {
      ...input,
      id: `p-${Date.now()}`,
      updatedAt: new Date().toISOString(),
    };
    setProducts(current => [product, ...current]);
  }, []);

  const updateStock = useCallback((id: string, delta: number) => {
    setProducts(current =>
      current.map(product =>
        product.id === id
          ? {
              ...product,
              stock: Math.max(0, product.stock + delta),
              updatedAt: new Date().toISOString(),
            }
          : product,
      ),
    );
  }, []);

  const deleteProduct = useCallback((id: string) => {
    setProducts(current => current.filter(product => product.id !== id));
  }, []);

  const addBill = useCallback(
    (input: NewBillInput): Bill => {
      const subtotal = input.items.reduce((sum, item) => sum + item.price * item.qty, 0);
      const discount = Math.min(Math.max(input.discount, 0), subtotal);
      const maxNumber = bills.reduce((max, bill) => {
        const value = Number(bill.number.replace('JVG-', ''));
        return Number.isFinite(value) ? Math.max(max, value) : max;
      }, 1000);

      const bill: Bill = {
        id: `b-${Date.now()}`,
        number: `JVG-${maxNumber + 1}`,
        customerName: input.customerName.trim() || 'वॉक-इन ग्राहक',
        customerPhone: input.customerPhone.trim(),
        items: input.items,
        subtotal,
        discount,
        total: subtotal - discount,
        paymentMode: input.paymentMode,
        settled: input.paymentMode !== 'udhaar',
        staffId: input.staffId,
        staffName: input.staffName,
        createdAt: new Date().toISOString(),
      };

      setBills(current => [bill, ...current]);
      setProducts(current =>
        current.map(product => {
          const sold = input.items.find(item => item.productId === product.id);
          if (!sold || product.category === 'बैंकिंग सेवा') return product;
          return {
            ...product,
            stock: Math.max(0, product.stock - sold.qty),
            updatedAt: new Date().toISOString(),
          };
        }),
      );

      return bill;
    },
    [bills],
  );

  const settleBill = useCallback((id: string) => {
    setBills(current =>
      current.map(bill => (bill.id === id ? { ...bill, settled: true } : bill)),
    );
  }, []);

  const deleteBill = useCallback((id: string) => {
    setBills(current => current.filter(bill => bill.id !== id));
  }, []);

  const addStaff = useCallback((input: NewStaffInput) => {
    const member: StaffMember = {
      ...input,
      id: `s-${Date.now()}`,
      present: true,
      joinedAt: new Date().toISOString(),
    };
    setStaff(current => [member, ...current]);
  }, []);

  const updateStaff = useCallback((id: string, input: NewStaffInput) => {
    setStaff(current =>
      current.map(member => (member.id === id ? { ...member, ...input } : member)),
    );
  }, []);

  const markAttendance = useCallback(
    (id: string, present: boolean, key: string = dateKey()) => {
      const today = dateKey();
      setStaff(current =>
        current.map(member =>
          member.id === id && key === today ? { ...member, present } : member,
        ),
      );
      setAttendance(current => ({
        ...current,
        [id]: { ...(current[id] ?? {}), [key]: present },
      }));
    },
    [],
  );

  const deleteStaff = useCallback((id: string) => {
    setStaff(current => current.filter(member => member.id !== id));
    setAttendance(current => {
      if (!(id in current)) return current;
      const next = { ...current };
      delete next[id];
      return next;
    });
  }, []);

  const value = useMemo<ShopContextValue>(
    () => ({
      ready,
      products,
      bills,
      staff,
      attendance,
      upiId,
      setUpiId,
      addProduct,
      updateStock,
      deleteProduct,
      addBill,
      settleBill,
      deleteBill,
      addStaff,
      updateStaff,
      markAttendance,
      deleteStaff,
    }),
    [
      ready,
      products,
      bills,
      staff,
      attendance,
      upiId,
      setUpiId,
      addProduct,
      updateStock,
      deleteProduct,
      addBill,
      settleBill,
      deleteBill,
      addStaff,
      updateStaff,
      markAttendance,
      deleteStaff,
    ],
  );

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}

export function useShop(): ShopContextValue {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used inside ShopProvider');
  }
  return context;
}
