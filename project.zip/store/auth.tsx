import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { useShop } from '@/store/shop';

export type Session =
  | { role: 'owner'; staffId: 'owner'; name: string; phone: string }
  | { role: 'staff'; staffId: string; name: string; phone: string };

type OwnerAccount = {
  name: string;
  phone: string;
  passwordHash: string;
};

type AuthContextValue = {
  ready: boolean;
  hasOwner: boolean;
  session: Session | null;
  setupOwner: (name: string, phone: string, password: string) => string | null;
  signInOwner: (phone: string, password: string) => string | null;
  resetOwnerPassword: (phone: string, password: string) => string | null;
  signInStaff: (phone: string) => string | null;
  signOut: () => void;
};

const AUTH_KEY = 'jvg-smarttech-auth-v1';

const AuthContext = createContext<AuthContextValue | null>(null);

function normalizePhone(value: string): string {
  return value.replace(/\D/g, '').slice(-10);
}

function hashPassword(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return `${(hash >>> 0).toString(16)}-${value.length}`;
}

type StoredAuth = {
  owner: OwnerAccount | null;
  session: Session | null;
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { staff } = useShop();
  const [ready, setReady] = useState(false);
  const [owner, setOwner] = useState<OwnerAccount | null>(null);
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    let alive = true;

    async function load() {
      try {
        const raw = await AsyncStorage.getItem(AUTH_KEY);
        if (raw && alive) {
          const parsed = JSON.parse(raw) as Partial<StoredAuth>;
          if (parsed.owner && typeof parsed.owner.phone === 'string') {
            setOwner(parsed.owner);
          }
          if (parsed.session && typeof parsed.session.role === 'string') {
            setSession(parsed.session);
          }
        }
      } catch {
        // A fresh login is shown when local auth data is unavailable.
      } finally {
        if (alive) setReady(true);
      }
    }

    load();

    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const state: StoredAuth = { owner, session };
    AsyncStorage.setItem(AUTH_KEY, JSON.stringify(state)).catch(() => {
      // Best-effort local storage; login still works for this session.
    });
  }, [ready, owner, session]);

  const setupOwner = useCallback(
    (name: string, phone: string, password: string): string | null => {
      const normalized = normalizePhone(phone);
      if (!name.trim()) return 'ओनर का नाम डालिए।';
      if (normalized.length !== 10) return 'ओनर का 10 अंकों का मोबाइल नंबर डालिए।';
      if (password.length < 4) return 'पासवर्ड कम से कम 4 अक्षर का रखिए।';

      const account: OwnerAccount = {
        name: name.trim(),
        phone: normalized,
        passwordHash: hashPassword(password),
      };
      setOwner(account);
      setSession({
        role: 'owner',
        staffId: 'owner',
        name: account.name,
        phone: account.phone,
      });
      return null;
    },
    [],
  );

  const signInOwner = useCallback(
    (phone: string, password: string): string | null => {
      if (!owner) return 'पहले ओनर अकाउंट बनाइए।';
      if (normalizePhone(phone) !== owner.phone) return 'ओनर का नंबर सही नहीं है।';
      if (hashPassword(password) !== owner.passwordHash) return 'पासवर्ड गलत है।';
      setSession({
        role: 'owner',
        staffId: 'owner',
        name: owner.name,
        phone: owner.phone,
      });
      return null;
    },
    [owner],
  );

  const resetOwnerPassword = useCallback(
    (phone: string, password: string): string | null => {
      if (!owner) return 'पहले ओनर अकाउंट बनाइए।';
      if (normalizePhone(phone) !== owner.phone) {
        return 'यह नंबर रजिस्टर्ड ओनर नंबर नहीं है।';
      }
      if (password.length < 4) return 'नया पासवर्ड कम से कम 4 अक्षर का रखिए।';
      setOwner({ ...owner, passwordHash: hashPassword(password) });
      return null;
    },
    [owner],
  );

  const signInStaff = useCallback(
    (phone: string): string | null => {
      const normalized = normalizePhone(phone);
      if (normalized.length !== 10) return '10 अंकों का मोबाइल नंबर डालिए।';
      const member = staff.find(
        item => normalizePhone(item.phone) === normalized,
      );
      if (!member) return 'यह नंबर स्टाफ सूची में नहीं है।';
      setSession({
        role: 'staff',
        staffId: member.id,
        name: member.name,
        phone: normalized,
      });
      return null;
    },
    [staff],
  );

  const signOut = useCallback(() => {
    setSession(null);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      ready,
      hasOwner: owner !== null,
      session,
      setupOwner,
      signInOwner,
      resetOwnerPassword,
      signInStaff,
      signOut,
    }),
    [
      ready,
      owner,
      session,
      setupOwner,
      signInOwner,
      resetOwnerPassword,
      signInStaff,
      signOut,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return context;
}
