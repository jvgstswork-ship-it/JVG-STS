import { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Stack, useRouter, useSegments, type Href } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { ShopProvider } from '@/store/shop';
import { AuthProvider, useAuth } from '@/store/auth';
import { colors } from '@/constants/theme';

function AuthGate({ children }: { children: React.ReactNode }) {
  const { ready, session } = useAuth();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (!ready) return;
    const inLogin = segments[0] === 'login';
    if (!session && !inLogin) {
      router.replace('/login' as Href);
    } else if (session && inLogin) {
      router.replace('/(tabs)' as Href);
    }
  }, [ready, session, segments, router]);

  if (!ready) {
    return (
      <View style={styles.splash}>
        <View style={styles.splashLogo}>
          <Text style={styles.splashLogoText}>JVG</Text>
        </View>
        <Text style={styles.splashTitle}>JVG SmartTech Suvidha</Text>
        <ActivityIndicator color={colors.brand} />
      </View>
    );
  }

  return <>{children}</>;
}

export default function RootLayout() {
  useFrameworkReady();

  return (
    <ShopProvider>
      <AuthProvider>
        <View style={styles.root}>
          <LinearGradient
            colors={['#e4f0e8', '#f7f2e4', '#e4edf5']}
            locations={[0, 0.55, 1]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFillObject}
          />
          <View style={[styles.blob, styles.blobAmber]} />
          <View style={[styles.blob, styles.blobGreen]} />
          <View style={[styles.blob, styles.blobBlue]} />

          <AuthGate>
            <Stack
              screenOptions={{
                headerShown: false,
                contentStyle: { backgroundColor: 'transparent' },
              }}
            >
              <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
              <Stack.Screen name="login" options={{ animation: 'fade' }} />
              <Stack.Screen name="+not-found" />
            </Stack>
          </AuthGate>
          <StatusBar style="dark" />
        </View>
      </AuthProvider>
    </ShopProvider>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#e9f0ea',
    overflow: 'hidden',
  },
  blob: {
    position: 'absolute',
    borderRadius: 999,
  },
  blobAmber: {
    width: 300,
    height: 300,
    top: -110,
    right: -120,
    backgroundColor: 'rgba(230, 162, 60, 0.22)',
  },
  blobGreen: {
    width: 280,
    height: 280,
    bottom: 40,
    left: -140,
    backgroundColor: 'rgba(29, 84, 64, 0.16)',
  },
  blobBlue: {
    width: 240,
    height: 240,
    top: '38%',
    right: -100,
    backgroundColor: 'rgba(76, 132, 168, 0.14)',
  },
  splash: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  splashLogo: {
    width: 64,
    height: 64,
    borderRadius: 22,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
  },
  splashLogoText: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.white,
    letterSpacing: 0.6,
  },
  splashTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
  },
});
