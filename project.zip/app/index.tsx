import { Redirect, type Href } from 'expo-router';
import { useAuth } from '@/store/auth';

export default function Index() {
  const { session } = useAuth();
  return <Redirect href={(session ? '/(tabs)' : '/login') as Href} />;
}
