import { Link, Stack } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';
import { CircleAlert } from 'lucide-react-native';
import { colors } from '@/constants/theme';

export default function NotFoundScreen() {
  return (
    <>
      <Stack.Screen options={{ title: 'पेज नहीं मिला' }} />
      <View style={styles.container}>
        <View style={styles.icon}>
          <CircleAlert size={28} color={colors.brand} />
        </View>
        <Text style={styles.title}>यह पेज नहीं मिला</Text>
        <Text style={styles.body}>
          जिस स्क्रीन को आप खोज रहे हैं वह मौजूद नहीं है।
        </Text>
        <Link href="/" style={styles.link}>
          <Text style={styles.linkText}>दुकान के होम पर जाएं</Text>
        </Link>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: 'transparent',
    gap: 8,
  },
  icon: {
    width: 62,
    height: 62,
    borderRadius: 20,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  title: {
    fontSize: 19,
    fontWeight: '800',
    color: colors.ink,
  },
  body: {
    fontSize: 13,
    color: colors.muted,
    textAlign: 'center',
  },
  link: {
    marginTop: 14,
    paddingVertical: 12,
    paddingHorizontal: 18,
    backgroundColor: colors.brand,
    borderRadius: 12,
  },
  linkText: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.white,
  },
});
