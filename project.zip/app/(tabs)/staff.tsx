import { useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  CalendarCheck,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  CircleAlert,
  FileText,
  Lock,
  Pencil,
  Phone,
  Trash2,
  TrendingUp,
  UserCheck,
  UserPlus,
  Users,
  Wallet,
  X,
} from 'lucide-react-native';
import {
  Badge,
  Card,
  Chip,
  EmptyState,
  PrimaryButton,
  SectionHeader,
} from '@/components/ui';
import { LoadingState } from '@/components/LoadingState';
import { LiquidBackground } from '@/components/LiquidBackground';
import { glass, colors, radius } from '@/constants/theme';
import { useShop, type StaffMember } from '@/store/shop';
import { useAuth } from '@/store/auth';
import { dateKey, monthCells, monthStats } from '@/utils/attendance';
import { formatINR, formatMonthYear, initials, isToday } from '@/utils/format';

const roles = [
  'बैंकिंग ऑपरेटर',
  'कैशियर',
  'सेल्स एक्ज़ीक्यूटिव',
  'मैनेजर',
  'हेल्पर',
];

const weekdayLabels = ['रवि', 'सोम', 'मं', 'बु', 'गु', 'शु', 'श'];

export default function StaffScreen() {
  const {
    ready,
    staff,
    bills,
    attendance,
    addStaff,
    updateStaff,
    markAttendance,
    deleteStaff,
  } = useShop();
  const { session } = useAuth();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [role, setRole] = useState(roles[0]);
  const [phone, setPhone] = useState('');
  const [salary, setSalary] = useState('');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState('');
  const [savedMessage, setSavedMessage] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<StaffMember | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [monthOffset, setMonthOffset] = useState(0);

  const isOwner = session?.role !== 'staff';

  const anchor = useMemo(() => {
    const date = new Date();
    date.setDate(1);
    date.setMonth(date.getMonth() + monthOffset);
    return date;
  }, [monthOffset]);

  const presentCount = staff.filter(member => member.present).length;
  const payroll = useMemo(
    () => staff.reduce((sum, member) => sum + member.salary, 0),
    [staff],
  );
  const attendancePct =
    staff.length === 0 ? 0 : Math.round((presentCount / staff.length) * 100);

  const selfMember = staff.find(member => member.id === session?.staffId) ?? null;
  const selfBills = useMemo(
    () =>
      bills.filter(
        bill => bill.staffId === session?.staffId && isToday(bill.createdAt),
      ),
    [bills, session?.staffId],
  );
  const selfSales = selfBills.reduce((sum, bill) => sum + bill.total, 0);

  function resetForm() {
    setShowForm(false);
    setEditingId(null);
    setName('');
    setPhone('');
    setSalary('');
    setNotes('');
    setRole(roles[0]);
    setFormError('');
  }

  function openAddForm() {
    resetForm();
    setShowForm(true);
    setSavedMessage('');
  }

  function openEditForm(member: StaffMember) {
    resetForm();
    setEditingId(member.id);
    setName(member.name);
    setRole(member.role);
    setPhone(member.phone);
    setSalary(String(member.salary));
    setNotes(member.notes ?? '');
    setShowForm(true);
    setSavedMessage('');
  }

  function handleSave() {
    const trimmed = name.trim();
    if (!trimmed) {
      setFormError('स्टाफ का नाम लिखिए।');
      return;
    }
    const normalizedPhone = phone.replace(/\D/g, '').slice(-10);
    if (normalizedPhone && normalizedPhone.length !== 10) {
      setFormError('मोबाइल नंबर 10 अंकों का होना चाहिए।');
      return;
    }
    const salaryValue = Number.parseInt(salary === '' ? '0' : salary, 10);
    if (!Number.isFinite(salaryValue) || salaryValue < 0) {
      setFormError('मासिक वेतन की सही राशि भरिए।');
      return;
    }

    const input = {
      name: trimmed,
      role,
      phone: normalizedPhone,
      salary: salaryValue,
      notes: notes.trim(),
    };

    if (editingId) {
      updateStaff(editingId, input);
      setSavedMessage(`${trimmed} की स्टाफ एडिट सेव हो गई।`);
    } else {
      addStaff(input);
      setSavedMessage(`${trimmed} को स्टाफ में जोड़ दिया गया।`);
    }
    setFormError('');
    resetForm();
  }

  function shiftMonth(delta: number) {
    setMonthOffset(current => Math.min(0, current + delta));
  }

  function renderMonthGrid(memberId: string, editable: boolean) {
    const cells = monthCells(attendance[memberId], anchor);
    const leading = cells[0]?.weekday ?? 0;
    const todayKey = dateKey();

    return (
      <View style={styles.monthBlock}>
        <View style={styles.monthNav}>
          <Pressable
            onPress={() => shiftMonth(-1)}
            style={styles.monthNavButton}
            accessibilityLabel="पिछला महीना"
          >
            <ChevronLeft size={15} color={colors.brand} />
          </Pressable>
          <Text style={styles.monthLabel}>{formatMonthYear(anchor)}</Text>
          <Pressable
            onPress={() => shiftMonth(1)}
            disabled={monthOffset === 0}
            style={[
              styles.monthNavButton,
              monthOffset === 0 && styles.monthNavDisabled,
            ]}
            accessibilityLabel="अगला महीना"
          >
            <ChevronRight size={15} color={colors.brand} />
          </Pressable>
        </View>

        <View style={styles.weekRow}>
          {weekdayLabels.map(label => (
            <Text key={label} style={styles.weekLabel}>
              {label}
            </Text>
          ))}
        </View>

        <View style={styles.grid}>
          {Array.from({ length: leading }).map((_, index) => (
            <View key={`blank-${index}`} style={styles.cell} />
          ))}
          {cells.map(cell => {
            const tone =
              cell.value === true
                ? styles.cellPresent
                : cell.value === false
                  ? styles.cellAbsent
                  : null;
            const textTone =
              cell.value === true
                ? styles.cellTextPresent
                : cell.value === false
                  ? styles.cellTextAbsent
                  : null;
            return (
              <Pressable
                key={cell.key}
                disabled={!editable || cell.key > todayKey}
                onPress={() => markAttendance(memberId, cell.value !== true, cell.key)}
                style={[
                  styles.cell,
                  tone,
                  cell.isToday && styles.cellToday,
                  cell.key > todayKey && styles.cellFuture,
                ]}
              >
                <Text style={[styles.cellText, textTone]}>{cell.day}</Text>
              </Pressable>
            );
          })}
        </View>

        <View style={styles.legendRow}>
          <View style={[styles.legendDot, { backgroundColor: colors.brand }]} />
          <Text style={styles.legendText}>हाज़िर</Text>
          <View style={[styles.legendDot, { backgroundColor: colors.danger }]} />
          <Text style={styles.legendText}>छुट्टी</Text>
          <Text style={styles.legendHint}>
            {editable ? 'दबाकर बदल सकते हैं' : 'सिर्फ देख सकते हैं'}
          </Text>
        </View>
      </View>
    );
  }

  if (!ready) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <LiquidBackground />
        <LoadingState label="स्टाफ की सूची खुल रही है…" />
      </SafeAreaView>
    );
  }

  if (!isOwner) {
    const month = monthStats(attendance[session?.staffId ?? ''], anchor);
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <LiquidBackground />
        <ScrollView
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <View style={styles.headerText}>
              <Text style={styles.title}>मेरी प्रोफाइल</Text>
              <Text style={styles.subtitle}>
                आपका नाम, नंबर और इस महीने की हाज़िरी।
              </Text>
            </View>
            <View style={styles.headerIcon}>
              <Users size={20} color={colors.brand} />
            </View>
          </View>

          <Card style={styles.profileCard}>
            <View
              style={[
                styles.avatar,
                { backgroundColor: colors.brandSoft, width: 52, height: 52 },
              ]}
            >
              <Text style={[styles.avatarText, { color: colors.brand }]}>
                {initials(session?.name ?? 'स्टाफ')}
              </Text>
            </View>
            <View style={styles.flex}>
              <Text style={styles.staffName}>{session?.name}</Text>
              <View style={styles.staffMetaRow}>
                <Badge label={selfMember?.role ?? 'स्टाफ'} tone="info" />
                <View style={styles.phoneRow}>
                  <Phone size={10} color={colors.muted} />
                  <Text style={styles.phoneText}>{session?.phone}</Text>
                </View>
              </View>
            </View>
          </Card>

          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <TrendingUp size={15} color={colors.brand} />
              <Text style={styles.statValue}>{formatINR(selfSales)}</Text>
              <Text style={styles.statLabel}>आज की मेरी बिक्री</Text>
            </View>
            <View style={styles.statCard}>
              <UserCheck size={15} color={colors.brandMid} />
              <Text style={styles.statValue}>
                {month.present}/{month.marked || 0}
              </Text>
              <Text style={styles.statLabel}>इस महीने हाज़िर</Text>
            </View>
          </View>

          <Card>
            <View style={styles.attendanceTop}>
              <View style={styles.attendanceIcon}>
                <CalendarCheck size={18} color={colors.brand} />
              </View>
              <View style={styles.flex}>
                <Text style={styles.attendanceTitle}>महीने की हाज़िरी</Text>
                <Text style={styles.attendanceCaption}>
                  हर दिन का रिकॉर्ड ओनर के मोबाइल में सेव रहता है
                </Text>
              </View>
            </View>
            {renderMonthGrid(session?.staffId ?? '', false)}
          </Card>

          <View style={styles.footerNote}>
            <Lock size={13} color={colors.muted} />
            <Text style={styles.footerText}>
              वेतन और पूरी टीम की हाज़िरी सिर्फ ओनर लॉगिन में दिखती है।
            </Text>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <LiquidBackground />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <View style={styles.headerText}>
              <Text style={styles.title}>स्टाफ और हाज़िरी</Text>
              <Text style={styles.subtitle}>
                स्टाफ एडिट, महीने की हाज़िरी, बिक्री और वेतन एक जगह।
              </Text>
            </View>
            <View style={styles.headerIcon}>
              <Users size={20} color={colors.brand} />
            </View>
          </View>

          <View style={styles.ownerTag}>
            <Lock size={11} color={colors.brand} />
            <Text style={styles.ownerTagText}>ओनर के लिए सुरक्षित</Text>
          </View>

          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <Users size={15} color={colors.info} />
              <Text style={styles.statValue}>{staff.length}</Text>
              <Text style={styles.statLabel}>कुल स्टाफ</Text>
            </View>
            <View style={styles.statCard}>
              <UserCheck size={15} color={colors.brandMid} />
              <Text style={styles.statValue}>
                {presentCount}/{staff.length}
              </Text>
              <Text style={styles.statLabel}>आज हाज़िर</Text>
            </View>
            <View style={styles.statCard}>
              <Wallet size={15} color="#8a5a12" />
              <Text style={styles.statValue}>{formatINR(payroll)}</Text>
              <Text style={styles.statLabel}>मासिक वेतन</Text>
            </View>
          </View>

          <Card style={styles.attendanceCard}>
            <View style={styles.attendanceTop}>
              <View style={styles.attendanceIcon}>
                <CalendarCheck size={18} color={colors.brand} />
              </View>
              <View style={styles.flex}>
                <Text style={styles.attendanceTitle}>आज की हाज़िरी</Text>
                <Text style={styles.attendanceCaption}>
                  {presentCount} लोग मौजूद · {staff.length - presentCount} छुट्टी पर
                </Text>
              </View>
              <Text style={styles.attendancePct}>{attendancePct}%</Text>
            </View>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${attendancePct}%` }]} />
            </View>
          </Card>

          {savedMessage ? (
            <View style={styles.successBox}>
              <CheckCircle2 size={17} color={colors.brandMid} />
              <Text style={styles.successText}>{savedMessage}</Text>
              <Pressable onPress={() => setSavedMessage('')} hitSlop={8}>
                <X size={15} color={colors.brandMid} />
              </Pressable>
            </View>
          ) : null}

          {showForm ? (
            <View>
              <SectionHeader
                title={editingId ? 'स्टाफ एडिट करें' : 'नया स्टाफ जोड़ें'}
                caption={
                  editingId
                    ? 'नाम से लेकर नोट तक सब कुछ बदल सकते हैं'
                    : 'बुनियादी जानकारी भरें'
                }
              />
              <Card style={styles.formCard}>
                <View>
                  <Text style={styles.fieldLabel}>पूरा नाम</Text>
                  <TextInput
                    value={name}
                    onChangeText={value => {
                      setName(value);
                      setFormError('');
                    }}
                    placeholder="जैसे: रमेश कुमार"
                    placeholderTextColor={colors.soft}
                    style={styles.input}
                  />
                </View>

                <View>
                  <Text style={styles.fieldLabel}>भूमिका</Text>
                  <View style={styles.roleRow}>
                    {roles.map(item => (
                      <Chip
                        key={item}
                        label={item}
                        active={role === item}
                        onPress={() => setRole(item)}
                      />
                    ))}
                  </View>
                </View>

                <View style={styles.inlineFields}>
                  <View style={styles.flex}>
                    <Text style={styles.fieldLabel}>मोबाइल नंबर</Text>
                    <TextInput
                      value={phone}
                      onChangeText={value => {
                        setPhone(value.replace(/\D/g, '').slice(0, 10));
                        setFormError('');
                      }}
                      placeholder="10 अंकों का नंबर"
                      placeholderTextColor={colors.soft}
                      keyboardType="phone-pad"
                      maxLength={10}
                      style={styles.input}
                    />
                  </View>
                  <View style={styles.flex}>
                    <Text style={styles.fieldLabel}>मासिक वेतन (₹)</Text>
                    <TextInput
                      value={salary}
                      onChangeText={value => {
                        setSalary(value.replace(/[^0-9]/g, ''));
                        setFormError('');
                      }}
                      placeholder="0"
                      placeholderTextColor={colors.soft}
                      keyboardType="number-pad"
                      style={styles.input}
                    />
                  </View>
                </View>

                <View>
                  <Text style={styles.fieldLabel}>नोट</Text>
                  <TextInput
                    value={notes}
                    onChangeText={setNotes}
                    placeholder="आईडी प्रूफ, पता या काम से जुड़ी जानकारी…"
                    placeholderTextColor={colors.soft}
                    style={[styles.input, styles.notesInput]}
                    multiline
                    textAlignVertical="top"
                  />
                </View>

                <Text style={styles.formHint}>
                  यही मोबाइल नंबर स्टाफ लॉगिन का आधार बनेगा।
                </Text>

                {formError ? (
                  <View style={styles.errorBox}>
                    <CircleAlert size={14} color={colors.danger} />
                    <Text style={styles.errorText}>{formError}</Text>
                  </View>
                ) : null}

                <View style={styles.formActions}>
                  <PrimaryButton
                    label="रद्द करें"
                    tone="ghost"
                    onPress={resetForm}
                    style={styles.flex}
                  />
                  <PrimaryButton
                    label={editingId ? 'एडिट सेव करें' : 'स्टाफ जोड़ें'}
                    onPress={handleSave}
                    icon={
                      editingId ? (
                        <Pencil size={16} color={colors.white} />
                      ) : (
                        <UserPlus size={16} color={colors.white} />
                      )
                    }
                    style={styles.flex}
                  />
                </View>
              </Card>
            </View>
          ) : (
            <PrimaryButton
              label="नया स्टाफ जोड़ें"
              tone="ghost"
              onPress={openAddForm}
              icon={<UserPlus size={17} color={colors.brand} />}
            />
          )}

          <View>
            <SectionHeader
              title="टीम की सूची"
              caption={`${staff.length} सदस्य`}
              action={staff.length > 0 ? 'सबको हाज़िर' : undefined}
              onAction={() => {
                staff
                  .filter(member => !member.present)
                  .forEach(member => markAttendance(member.id, true));
              }}
            />
            {staff.length === 0 ? (
              <Card>
                <EmptyState
                  icon={<Users size={24} color={colors.brand} />}
                  title="अभी कोई स्टाफ नहीं"
                  body="ऊपर के बटन से अपनी दुकान के पहले सदस्य को जोड़िए।"
                />
              </Card>
            ) : (
              <View style={styles.staffList}>
                {staff.map(member => {
                  const memberBills = bills.filter(
                    bill =>
                      bill.staffId === member.id && isToday(bill.createdAt),
                  );
                  const salesToday = memberBills.reduce(
                    (sum, bill) => sum + bill.total,
                    0,
                  );
                  const stats = monthStats(attendance[member.id], anchor);
                  const expanded = expandedId === member.id;
                  return (
                    <Card key={member.id} style={styles.staffCard}>
                      <View style={styles.staffTop}>
                        <View
                          style={[
                            styles.avatar,
                            {
                              backgroundColor: member.present
                                ? colors.brandSoft
                                : 'rgba(255,255,255,0.4)',
                            },
                          ]}
                        >
                          <Text
                            style={[
                              styles.avatarText,
                              {
                                color: member.present
                                  ? colors.brand
                                  : colors.muted,
                              },
                            ]}
                          >
                            {initials(member.name)}
                          </Text>
                        </View>
                        <View style={styles.staffInfo}>
                          <Text style={styles.staffName} numberOfLines={1}>
                            {member.name}
                          </Text>
                          <View style={styles.staffMetaRow}>
                            <Badge label={member.role} tone="info" />
                            {member.phone ? (
                              <View style={styles.phoneRow}>
                                <Phone size={10} color={colors.muted} />
                                <Text style={styles.phoneText}>{member.phone}</Text>
                              </View>
                            ) : null}
                          </View>
                        </View>
                        <View style={styles.cardActions}>
                          <Pressable
                            onPress={() => openEditForm(member)}
                            hitSlop={6}
                            accessibilityLabel="स्टाफ एडिट करें"
                            style={styles.editButton}
                          >
                            <Pencil size={12} color={colors.brandMid} />
                            <Text style={styles.editButtonText}>एडिट</Text>
                          </Pressable>
                          <Pressable
                            onPress={() => setDeleteTarget(member)}
                            hitSlop={6}
                            accessibilityLabel="स्टाफ हटाएं"
                          >
                            <Trash2 size={15} color={colors.danger} />
                          </Pressable>
                        </View>
                      </View>

                      {member.notes ? (
                        <View style={styles.fileNote}>
                          <FileText size={12} color={colors.muted} />
                          <Text style={styles.fileNoteText} numberOfLines={2}>
                            {member.notes}
                          </Text>
                        </View>
                      ) : null}

                      <View style={styles.salesRow}>
                        <View style={styles.salesIcon}>
                          <TrendingUp size={15} color={colors.brandMid} />
                        </View>
                        <View style={styles.flex}>
                          <Text style={styles.salesLabel}>आज की बिक्री</Text>
                          <Text style={styles.salesMeta}>
                            {memberBills.length} बिल इस स्टाफ के नाम
                          </Text>
                        </View>
                        <Text style={styles.salesValue}>{formatINR(salesToday)}</Text>
                      </View>

                      <Pressable
                        onPress={() => setExpandedId(expanded ? null : member.id)}
                        style={styles.monthToggle}
                      >
                        <CalendarCheck size={14} color={colors.brand} />
                        <Text style={styles.monthToggleText}>
                          {formatMonthYear(anchor)} की हाज़िरी · {stats.present} हाज़िर
                        </Text>
                        {expanded ? (
                          <ChevronUp size={15} color={colors.brand} />
                        ) : (
                          <ChevronDown size={15} color={colors.brand} />
                        )}
                      </Pressable>

                      {expanded ? renderMonthGrid(member.id, true) : null}

                      <View style={styles.staffBottom}>
                        <View>
                          <Text style={styles.salaryLabel}>मासिक वेतन</Text>
                          <Text style={styles.salaryValue}>{formatINR(member.salary)}</Text>
                        </View>
                        <View style={styles.attendanceToggle}>
                          <Pressable
                            onPress={() => markAttendance(member.id, true)}
                            style={[
                              styles.toggleButton,
                              member.present && styles.togglePresent,
                            ]}
                          >
                            <Text
                              style={[
                                styles.toggleText,
                                member.present && styles.toggleTextActive,
                              ]}
                            >
                              हाज़िर
                            </Text>
                          </Pressable>
                          <Pressable
                            onPress={() => markAttendance(member.id, false)}
                            style={[
                              styles.toggleButton,
                              !member.present && styles.toggleAbsent,
                            ]}
                          >
                            <Text
                              style={[
                                styles.toggleText,
                                !member.present && styles.toggleAbsentText,
                              ]}
                            >
                              छुट्टी
                            </Text>
                          </Pressable>
                        </View>
                      </View>
                    </Card>
                  );
                })}
              </View>
            )}
          </View>

          <View style={styles.footerNote}>
            <Lock size={13} color={colors.muted} />
            <Text style={styles.footerText}>
              हाज़िरी, वेतन और स्टाफ लॉगिन सिर्फ ओनर के मोबाइल में सेव रहते हैं।
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={deleteTarget !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setDeleteTarget(null)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.deleteIcon}>
              <Trash2 size={24} color={colors.danger} />
            </View>
            <Text style={styles.modalTitle}>स्टाफ हटाना है?</Text>
            <Text style={styles.modalBody}>
              {deleteTarget ? `${deleteTarget.name} · ${deleteTarget.role}` : ''}
            </Text>
            <Text style={styles.modalWarn}>हाज़िरी का रिकॉर्ड भी हट जाएगा।</Text>
            <View style={styles.modalActions}>
              <PrimaryButton
                label="रद्द करें"
                tone="ghost"
                onPress={() => setDeleteTarget(null)}
                style={styles.flex}
              />
              <PrimaryButton
                label="हटाएं"
                tone="danger"
                onPress={() => {
                  if (deleteTarget) deleteStaff(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                style={styles.flex}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 18,
    paddingTop: 10,
    paddingBottom: 32,
    gap: 18,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 10,
  },
  headerText: {
    flex: 1,
    gap: 4,
  },
  title: {
    fontSize: 23,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 12.5,
    color: colors.muted,
    lineHeight: 18,
  },
  headerIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ownerTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'flex-start',
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginTop: -8,
  },
  ownerTagText: {
    fontSize: 10,
    fontWeight: '800',
    color: colors.brand,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 9,
  },
  statCard: {
    flex: 1,
    backgroundColor: glass.fill,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 12,
    gap: 3,
  },
  statValue: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.2,
  },
  statLabel: {
    fontSize: 9.5,
    color: colors.muted,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  attendanceCard: {
    gap: 11,
  },
  attendanceTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  attendanceIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  attendanceTitle: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.ink,
  },
  attendanceCaption: {
    fontSize: 10.5,
    color: colors.muted,
    marginTop: 1,
  },
  attendancePct: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.brand,
    letterSpacing: -0.3,
  },
  progressTrack: {
    height: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.4)',
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 999,
    backgroundColor: colors.brandMid,
  },
  successBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.md,
    padding: 12,
    marginTop: -6,
  },
  successText: {
    flex: 1,
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.brand,
  },
  formCard: {
    gap: 12,
  },
  fieldLabel: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.ink,
    marginBottom: 6,
  },
  input: {
    minHeight: 46,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.input,
    paddingHorizontal: 12,
    fontSize: 13.5,
    color: colors.ink,
  },
  roleRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
  },
  notesInput: {
    minHeight: 72,
    paddingTop: 11,
    paddingBottom: 11,
  },
  inlineFields: {
    flexDirection: 'row',
    gap: 10,
  },
  formHint: {
    fontSize: 10.5,
    color: colors.muted,
    marginTop: -4,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(251,233,231,0.9)',
    borderRadius: 10,
    padding: 10,
  },
  errorText: {
    flex: 1,
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.danger,
  },
  formActions: {
    flexDirection: 'row',
    gap: 9,
  },
  staffList: {
    gap: 9,
  },
  staffCard: {
    gap: 11,
  },
  staffTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 14,
    fontWeight: '800',
  },
  staffInfo: {
    flex: 1,
    gap: 4,
  },
  staffName: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.ink,
  },
  staffMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  cardActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 13,
    paddingTop: 2,
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: 8,
    paddingHorizontal: 7,
    paddingVertical: 4,
  },
  editButtonText: {
    fontSize: 9.5,
    fontWeight: '800',
    color: colors.brandMid,
  },
  fileNote: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.4)',
    borderRadius: 10,
    padding: 9,
  },
  fileNoteText: {
    flex: 1,
    fontSize: 10.5,
    color: colors.muted,
    lineHeight: 15,
  },
  phoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  phoneText: {
    fontSize: 10,
    color: colors.muted,
  },
  salesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    backgroundColor: 'rgba(255,255,255,0.4)',
    borderRadius: 12,
    padding: 10,
  },
  salesIcon: {
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  salesLabel: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.ink,
  },
  salesMeta: {
    fontSize: 9.5,
    color: colors.muted,
  },
  salesValue: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.brand,
  },
  monthToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 2,
  },
  monthToggleText: {
    flex: 1,
    fontSize: 11,
    fontWeight: '700',
    color: colors.brand,
  },
  monthBlock: {
    backgroundColor: 'rgba(255,255,255,0.42)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 10,
    gap: 7,
  },
  monthNav: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  monthNavButton: {
    width: 28,
    height: 28,
    borderRadius: 9,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  monthNavDisabled: {
    opacity: 0.35,
  },
  monthLabel: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.ink,
  },
  weekRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 1,
  },
  weekLabel: {
    width: 33,
    textAlign: 'center',
    fontSize: 8.5,
    fontWeight: '800',
    color: colors.soft,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
  },
  cell: {
    width: 33,
    height: 33,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.35)',
  },
  cellPresent: {
    backgroundColor: colors.brand,
  },
  cellAbsent: {
    backgroundColor: colors.dangerSoft,
  },
  cellToday: {
    borderWidth: 1.5,
    borderColor: colors.accent,
  },
  cellFuture: {
    opacity: 0.35,
  },
  cellText: {
    fontSize: 10.5,
    fontWeight: '700',
    color: colors.soft,
  },
  cellTextPresent: {
    color: colors.white,
  },
  cellTextAbsent: {
    color: colors.danger,
  },
  legendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  legendDot: {
    width: 7,
    height: 7,
    borderRadius: 999,
  },
  legendText: {
    fontSize: 8.5,
    color: colors.muted,
    marginRight: 3,
  },
  legendHint: {
    flex: 1,
    textAlign: 'right',
    fontSize: 8.5,
    color: colors.soft,
  },
  staffBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: glass.line,
    paddingTop: 10,
  },
  salaryLabel: {
    fontSize: 9.5,
    color: colors.muted,
  },
  salaryValue: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.ink,
  },
  attendanceToggle: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.4)',
    borderRadius: 999,
    padding: 3,
    gap: 2,
  },
  toggleButton: {
    paddingHorizontal: 13,
    paddingVertical: 6,
    borderRadius: 999,
  },
  togglePresent: {
    backgroundColor: colors.brand,
  },
  toggleAbsent: {
    backgroundColor: colors.dangerSoft,
  },
  toggleText: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.muted,
  },
  toggleTextActive: {
    color: colors.white,
  },
  toggleAbsentText: {
    color: colors.danger,
  },
  footerNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 4,
  },
  footerText: {
    flex: 1,
    fontSize: 10.5,
    color: colors.muted,
    textAlign: 'center',
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(12, 30, 23, 0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 380,
    backgroundColor: glass.overlay,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.xl,
    padding: 22,
    alignItems: 'center',
    gap: 6,
  },
  deleteIcon: {
    width: 58,
    height: 58,
    borderRadius: 20,
    backgroundColor: colors.dangerSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
  },
  modalBody: {
    fontSize: 12,
    color: colors.muted,
    textAlign: 'center',
  },
  modalWarn: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.danger,
    marginTop: 2,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 9,
    width: '100%',
    marginTop: 12,
  },
});
