import { useMemo, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, type Href } from 'expo-router';
import {
  ArrowUpRight,
  ChevronRight,
  CircleAlert,
  History,
  LogOut,
  Package,
  Phone,
  ReceiptText,
  ShieldCheck,
  Store,
  TrendingUp,
  Upload,
  UserCheck,
  Users,
  Wallet,
} from 'lucide-react-native';
import { Badge, Card, EmptyState, PrimaryButton, SectionHeader } from '@/components/ui';
import { LiquidBackground } from '@/components/LiquidBackground';
import { categoryTone, colors, glass, radius } from '@/constants/theme';
import { useShop } from '@/store/shop';
import { useAuth } from '@/store/auth';
import { formatINR, formatLongDate, formatTime, greeting, initials, isToday } from '@/utils/format';
import { paymentMeta } from '@/utils/payments';

export default function HomeScreen() {
  const router = useRouter();
  const { products, bills, staff } = useShop();
  const { session, signOut } = useAuth();
  const [logoutOpen, setLogoutOpen] = useState(false);

  const isOwner = session?.role !== 'staff';
  const go = (path: string) => router.push(path as Href);

  const {
    myBills,
    todayBills,
    todaySales,
    outstanding,
    lowStock,
    presentStaff,
    recentBills,
  } = useMemo(() => {
    const scopedBills = isOwner
      ? bills
      : bills.filter(bill => bill.staffId === session?.staffId);
    const today = scopedBills.filter(bill => isToday(bill.createdAt));
    return {
      myBills: scopedBills,
      todayBills: today,
      todaySales: today.reduce((sum, bill) => sum + bill.total, 0),
      outstanding: scopedBills
        .filter(bill => bill.paymentMode === 'udhaar' && !bill.settled)
        .reduce((sum, bill) => sum + bill.total, 0),
      lowStock: products
        .filter(product => product.stock <= 5)
        .sort((a, b) => a.stock - b.stock),
      presentStaff: staff.filter(member => member.present).length,
      recentBills: [...scopedBills]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 4),
    };
  }, [bills, products, staff, isOwner, session?.staffId]);

  const staffSales = useMemo(
    () =>
      staff
        .map(member => {
          const memberBills = bills.filter(
            bill => bill.staffId === member.id && isToday(bill.createdAt),
          );
          return {
            member,
            count: memberBills.length,
            total: memberBills.reduce((sum, bill) => sum + bill.total, 0),
          };
        })
        .sort((a, b) => b.total - a.total),
    [bills, staff],
  );

  const quickActions = [
    {
      label: 'बिलिंग',
      caption: 'नया बिल',
      icon: <ReceiptText size={20} color={colors.brand} />,
      bg: colors.brandSoft,
      onPress: () => go('/billing'),
    },
    {
      label: 'इतिहास',
      caption: isOwner ? 'पुराने बिल' : 'मेरे बिल',
      icon: <History size={20} color={colors.info} />,
      bg: colors.infoSoft,
      onPress: () => go('/history'),
    },
    ...(isOwner
      ? [
          {
            label: 'प्रोडक्ट',
            caption: 'स्टॉक जोड़ें',
            icon: <Upload size={20} color="#8a5a12" />,
            bg: colors.accentSoft,
            onPress: () => go('/upload'),
          },
          {
            label: 'स्टाफ',
            caption: 'हाज़िरी',
            icon: <Users size={20} color="#6a4b8a" />,
            bg: '#efe8f6',
            onPress: () => go('/staff'),
          },
        ]
      : [
          {
            label: 'मेरी बिक्री',
            caption: 'आज का हिसाब',
            icon: <TrendingUp size={20} color="#8a5a12" />,
            bg: colors.accentSoft,
            onPress: () => go('/history'),
          },
        ]),
  ];

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <LiquidBackground />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.brandRow}>
            <View style={styles.brandMark}>
              <Store size={18} color={colors.white} />
            </View>
            <View style={styles.flex}>
              <Text style={styles.brandName}>JVG SmartTech Suvidha</Text>
              <Text style={styles.brandCaption}>
                किराना · इलेक्ट्रॉनिक्स · बैंकिंग सेवा
              </Text>
            </View>
          </View>
          <Pressable
            onPress={() => setLogoutOpen(true)}
            style={styles.logoutButton}
            accessibilityLabel="लॉगआउट"
          >
            <LogOut size={16} color={colors.brand} />
          </Pressable>
        </View>

        <View style={styles.sessionCard}>
          <View style={styles.sessionAvatar}>
            <Text style={styles.sessionAvatarText}>
              {initials(session?.name ?? 'मालिक')}
            </Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.sessionName}>{session?.name ?? 'मालिक'}</Text>
            <View style={styles.sessionMetaRow}>
              <Badge
                label={isOwner ? 'ओनर' : 'स्टाफ'}
                tone={isOwner ? 'brand' : 'info'}
              />
              <View style={styles.sessionPhoneRow}>
                <Phone size={10} color={colors.muted} />
                <Text style={styles.sessionPhone}>{session?.phone}</Text>
              </View>
            </View>
          </View>
          <Text style={styles.sessionDate}>{formatLongDate(new Date())}</Text>
        </View>

        <View style={styles.greetingWrap}>
          <Text style={styles.greeting}>
            {greeting()}, {session?.name ?? 'दुकानदार जी'}
          </Text>
          <Text style={styles.greetingSub}>
            {isOwner
              ? 'आज की बिक्री और स्टाफ का हिसाब एक नज़र में देखिए।'
              : 'आज आपकी बिक्री और बिल यहाँ दिखेंगे।'}
          </Text>
        </View>

        <LinearGradient
          colors={['#1a5341', '#0e2f25']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.hero}
        >
          <View style={styles.heroTop}>
            <View style={styles.heroSales}>
              <Text style={styles.heroLabel}>
                {isOwner ? 'आज की कुल बिक्री' : 'आज की मेरी बिक्री'}
              </Text>
              <Text style={styles.heroAmount}>{formatINR(todaySales)}</Text>
              <Text style={styles.heroMeta}>
                {todayBills.length} बिल · नकद + UPI + उधार
              </Text>
            </View>
            <View style={styles.heroTrend}>
              <ArrowUpRight size={14} color="#d6f0df" />
              <Text style={styles.heroTrendText}>लाइव</Text>
            </View>
          </View>

          <View style={styles.heroDivider} />

          <View style={styles.heroBottom}>
            <View>
              <Text style={styles.heroMiniLabel}>कुल उधार बाकी</Text>
              <Text style={styles.heroMiniValue}>{formatINR(outstanding)}</Text>
            </View>
            <Pressable style={styles.heroCta} onPress={() => go('/billing')}>
              <Text style={styles.heroCtaText}>नया बिल बनाएं</Text>
              <ArrowUpRight size={16} color={colors.brand} />
            </Pressable>
          </View>
        </LinearGradient>

        <View style={styles.statsGrid}>
          <View style={styles.statTile}>
            <View style={[styles.statIcon, { backgroundColor: colors.brandSoft }]}>
              <ReceiptText size={17} color={colors.brand} />
            </View>
            <Text style={styles.statValue}>{todayBills.length}</Text>
            <Text style={styles.statLabel}>आज के बिल</Text>
          </View>
          <View style={styles.statTile}>
            <View style={[styles.statIcon, { backgroundColor: colors.infoSoft }]}>
              <Wallet size={17} color={colors.info} />
            </View>
            <Text style={styles.statValue}>{myBills.length}</Text>
            <Text style={styles.statLabel}>
              {isOwner ? 'कुल बिल रिकॉर्ड' : 'मेरे कुल बिल'}
            </Text>
          </View>
          {isOwner ? (
            <>
              <View style={styles.statTile}>
                <View style={[styles.statIcon, { backgroundColor: colors.accentSoft }]}>
                  <Package size={17} color="#8a5a12" />
                </View>
                <Text style={styles.statValue}>{lowStock.length}</Text>
                <Text style={styles.statLabel}>कम स्टॉक प्रोडक्ट</Text>
              </View>
              <View style={styles.statTile}>
                <View style={[styles.statIcon, { backgroundColor: '#efe8f6' }]}>
                  <UserCheck size={17} color="#6a4b8a" />
                </View>
                <Text style={styles.statValue}>
                  {presentStaff}/{staff.length}
                </Text>
                <Text style={styles.statLabel}>स्टाफ आज हाज़िर</Text>
              </View>
            </>
          ) : (
            <>
              <View style={styles.statTile}>
                <View style={[styles.statIcon, { backgroundColor: colors.accentSoft }]}>
                  <TrendingUp size={17} color="#8a5a12" />
                </View>
                <Text style={styles.statValue}>
                  {formatINR(
                    todayBills.length === 0 ? 0 : todaySales / todayBills.length,
                  )}
                </Text>
                <Text style={styles.statLabel}>औसत बिल राशि</Text>
              </View>
              <View style={styles.statTile}>
                <View style={[styles.statIcon, { backgroundColor: '#efe8f6' }]}>
                  <Users size={17} color="#6a4b8a" />
                </View>
                <Text style={styles.statValue}>{staff.length}</Text>
                <Text style={styles.statLabel}>टीम के सदस्य</Text>
              </View>
            </>
          )}
        </View>

        <View>
          <SectionHeader title="तुरंत काम" caption="एक टैप में शुरू करें" />
          <View style={styles.quickGrid}>
            {quickActions.map(action => (
              <Pressable
                key={action.label}
                onPress={action.onPress}
                style={({ pressed }) => [
                  styles.quickTile,
                  pressed && styles.quickTilePressed,
                ]}
              >
                <View style={[styles.quickIcon, { backgroundColor: action.bg }]}>
                  {action.icon}
                </View>
                <Text style={styles.quickLabel}>{action.label}</Text>
                <Text style={styles.quickCaption}>{action.caption}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {isOwner ? (
          <View>
            <SectionHeader
              title="स्टाफ की आज की बिक्री"
              caption="कौन कितना बेच रहा है"
              action="पूरी टीम"
              onAction={() => go('/staff')}
            />
            <Card style={styles.listCard}>
              {staffSales.length === 0 ? (
                <EmptyState
                  icon={<Users size={24} color={colors.brand} />}
                  title="टीम खाली है"
                  body="स्टाफ टैब से अपनी टीम जोड़िए, फिर हर सदस्य की बिक्री यहाँ दिखेगी।"
                />
              ) : (
                staffSales.map((row, index) => (
                  <View
                    key={row.member.id}
                    style={[
                      styles.staffSaleRow,
                      index !== staffSales.length - 1 && styles.rowDivider,
                    ]}
                  >
                    <View style={styles.staffSaleAvatar}>
                      <Text style={styles.staffSaleAvatarText}>
                        {initials(row.member.name)}
                      </Text>
                    </View>
                    <View style={styles.flex}>
                      <Text style={styles.staffSaleName} numberOfLines={1}>
                        {row.member.name}
                      </Text>
                      <Text style={styles.staffSaleMeta}>
                        {row.count} बिल · {row.member.present ? 'हाज़िर' : 'छुट्टी'}
                      </Text>
                    </View>
                    <View style={styles.staffSaleRight}>
                      <Text style={styles.staffSaleValue}>
                        {formatINR(row.total)}
                      </Text>
                      <Badge
                        label={row.member.present ? 'आज हाज़िर' : 'छुट्टी'}
                        tone={row.member.present ? 'brand' : 'muted'}
                      />
                    </View>
                  </View>
                ))
              )}
            </Card>
          </View>
        ) : null}

        <View>
          <SectionHeader
            title={isOwner ? 'हाल के बिल' : 'मेरे हाल के बिल'}
            caption={recentBills.length ? 'सबसे नए लेन-देन' : undefined}
            action="सभी देखें"
            onAction={() => go('/history')}
          />
          <Card style={styles.listCard}>
            {recentBills.length === 0 ? (
              <EmptyState
                icon={<ReceiptText size={24} color={colors.brand} />}
                title="अभी कोई बिल नहीं"
                body="बिलिंग टैब से पहला बिल बनाइए और अपनी बिक्री ट्रैक करना शुरू कीजिए।"
              />
            ) : (
              recentBills.map((bill, index) => {
                const meta = paymentMeta(bill.paymentMode, bill.settled);
                return (
                  <Pressable
                    key={bill.id}
                    onPress={() => go('/history')}
                    style={({ pressed }) => [
                      styles.billRow,
                      index !== recentBills.length - 1 && styles.rowDivider,
                      pressed && styles.rowPressed,
                    ]}
                  >
                    <View style={styles.billAvatar}>
                      <Text style={styles.billAvatarText}>
                        {initials(bill.customerName)}
                      </Text>
                    </View>
                    <View style={styles.billMain}>
                      <Text style={styles.billName} numberOfLines={1}>
                        {bill.customerName}
                      </Text>
                      <Text style={styles.billMeta} numberOfLines={1}>
                        {bill.number} · {formatTime(bill.createdAt)}
                        {isOwner ? ` · ${bill.staffName}` : ''}
                      </Text>
                    </View>
                    <View style={styles.billRight}>
                      <Text style={styles.billAmount}>{formatINR(bill.total)}</Text>
                      <Badge label={meta.label} tone={meta.tone} />
                    </View>
                  </Pressable>
                );
              })
            )}
          </Card>
        </View>

        {isOwner && lowStock.length > 0 ? (
          <View>
            <SectionHeader
              title="स्टॉक अलर्ट"
              caption="तुरंत भरपाई करें"
              action="स्टॉक अपडेट"
              onAction={() => go('/upload')}
            />
            <Card style={styles.listCard}>
              {lowStock.slice(0, 4).map((product, index) => {
                const tone = categoryTone[product.category] ?? categoryTone['अन्य'];
                return (
                  <View
                    key={product.id}
                    style={[
                      styles.stockRow,
                      index !== Math.min(lowStock.length, 4) - 1 && styles.rowDivider,
                    ]}
                  >
                    <View style={[styles.stockTile, { backgroundColor: tone.bg }]}>
                      <Text style={[styles.stockInitial, { color: tone.text }]}>
                        {product.name.slice(0, 1)}
                      </Text>
                    </View>
                    <View style={styles.stockMain}>
                      <Text style={styles.stockName} numberOfLines={1}>
                        {product.name}
                      </Text>
                      <View style={styles.stockAlertRow}>
                        <CircleAlert size={12} color={colors.danger} />
                        <Text style={styles.stockAlertText}>
                          सिर्फ {product.stock} {product.unit} बचे
                        </Text>
                      </View>
                    </View>
                    <Pressable onPress={() => go('/upload')} hitSlop={6}>
                      <Text style={styles.stockAction}>भरें</Text>
                    </Pressable>
                  </View>
                );
              })}
            </Card>
          </View>
        ) : null}

        <View style={styles.footerNote}>
          <ShieldCheck size={15} color={colors.muted} />
          <Text style={styles.footerText}>
            {isOwner
              ? 'बिल, स्टॉक और हाज़िरी का डेटा सिर्फ आपके इस मोबाइल में सुरक्षित है।'
              : 'आपका बिल और बिक्री का डेटा सिर्फ ओनर के मोबाइल में सेव होता है।'}
          </Text>
          <ChevronRight size={15} color={colors.soft} />
        </View>
      </ScrollView>

      <Modal
        visible={logoutOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setLogoutOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.logoutIcon}>
              <LogOut size={22} color={colors.brand} />
            </View>
            <Text style={styles.modalTitle}>लॉगआउट करना है?</Text>
            <Text style={styles.modalBody}>
              {session?.name} · {session?.phone}
            </Text>
            <View style={styles.modalActions}>
              <PrimaryButton
                label="रहने दें"
                tone="ghost"
                onPress={() => setLogoutOpen(false)}
                style={styles.flex}
              />
              <PrimaryButton
                label="लॉगआउट"
                onPress={() => {
                  setLogoutOpen(false);
                  signOut();
                }}
                style={styles.flex}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 18,
    paddingTop: 10,
    paddingBottom: 32,
    gap: 22,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  brandMark: {
    width: 38,
    height: 38,
    borderRadius: 13,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandName: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.1,
  },
  brandCaption: {
    fontSize: 11,
    color: colors.muted,
    marginTop: 1,
  },
  logoutButton: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sessionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: glass.fill,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.lg,
    padding: 12,
  },
  sessionAvatar: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sessionAvatarText: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.white,
  },
  sessionName: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.ink,
  },
  sessionMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginTop: 3,
  },
  sessionPhoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  sessionPhone: {
    fontSize: 10.5,
    color: colors.muted,
  },
  sessionDate: {
    fontSize: 9.5,
    fontWeight: '700',
    color: colors.muted,
    maxWidth: 90,
    textAlign: 'right',
  },
  greetingWrap: {
    gap: 4,
    marginTop: -8,
  },
  greeting: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.5,
  },
  greetingSub: {
    fontSize: 13,
    color: colors.muted,
    lineHeight: 19,
  },
  hero: {
    borderRadius: radius.xl,
    padding: 20,
    marginTop: -6,
  },
  heroTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12,
  },
  heroSales: {
    flex: 1,
    gap: 4,
  },
  heroLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#b8d6c7',
    letterSpacing: 0.3,
  },
  heroAmount: {
    fontSize: 34,
    fontWeight: '800',
    color: colors.white,
    letterSpacing: -1,
  },
  heroMeta: {
    fontSize: 11.5,
    color: '#a9c6b8',
  },
  heroTrend: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.13)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  heroTrendText: {
    fontSize: 11,
    fontWeight: '800',
    color: '#d6f0df',
  },
  heroDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.14)',
    marginVertical: 16,
  },
  heroBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  heroMiniLabel: {
    fontSize: 11,
    color: '#a9c6b8',
    fontWeight: '600',
  },
  heroMiniValue: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.white,
    marginTop: 2,
  },
  heroCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.accent,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
  },
  heroCtaText: {
    fontSize: 12.5,
    fontWeight: '800',
    color: colors.brand,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: -8,
  },
  statTile: {
    flexBasis: '47%',
    flexGrow: 1,
    backgroundColor: glass.fill,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 14,
    gap: 3,
  },
  statIcon: {
    width: 34,
    height: 34,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  statValue: {
    fontSize: 19,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.4,
  },
  statLabel: {
    fontSize: 11,
    color: colors.muted,
    lineHeight: 15,
  },
  quickGrid: {
    flexDirection: 'row',
    gap: 9,
  },
  quickTile: {
    flex: 1,
    backgroundColor: glass.fill,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: glass.border,
    paddingVertical: 13,
    paddingHorizontal: 9,
    gap: 5,
  },
  quickTilePressed: {
    backgroundColor: glass.fillStrong,
  },
  quickIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 3,
  },
  quickLabel: {
    fontSize: 12.5,
    fontWeight: '800',
    color: colors.ink,
  },
  quickCaption: {
    fontSize: 10,
    color: colors.muted,
  },
  listCard: {
    padding: 4,
  },
  staffSaleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
    paddingVertical: 11,
    paddingHorizontal: 10,
  },
  staffSaleAvatar: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  staffSaleAvatarText: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.brand,
  },
  staffSaleName: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.ink,
  },
  staffSaleMeta: {
    fontSize: 10.5,
    color: colors.muted,
    marginTop: 2,
  },
  staffSaleRight: {
    alignItems: 'flex-end',
    gap: 4,
  },
  staffSaleValue: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.brand,
  },
  billRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
    paddingVertical: 11,
    paddingHorizontal: 10,
  },
  rowDivider: {
    borderBottomWidth: 1,
    borderBottomColor: glass.line,
  },
  rowPressed: {
    backgroundColor: glass.fillStrong,
  },
  billAvatar: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  billAvatarText: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.brand,
  },
  billMain: {
    flex: 1,
    gap: 2,
  },
  billName: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.ink,
  },
  billMeta: {
    fontSize: 11,
    color: colors.muted,
  },
  billRight: {
    alignItems: 'flex-end',
    gap: 4,
  },
  billAmount: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.ink,
  },
  stockRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
    paddingVertical: 11,
    paddingHorizontal: 10,
  },
  stockTile: {
    width: 40,
    height: 40,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stockInitial: {
    fontSize: 16,
    fontWeight: '800',
  },
  stockMain: {
    flex: 1,
    gap: 3,
  },
  stockName: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.ink,
  },
  stockAlertRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  stockAlertText: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.danger,
  },
  stockAction: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.brandMid,
    paddingHorizontal: 4,
  },
  footerNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 2,
  },
  footerText: {
    flex: 1,
    fontSize: 10.5,
    color: colors.muted,
    lineHeight: 15,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(12, 30, 23, 0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: glass.overlay,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.xl,
    padding: 22,
    alignItems: 'center',
    gap: 6,
  },
  logoutIcon: {
    width: 54,
    height: 54,
    borderRadius: 18,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
  },
  modalBody: {
    fontSize: 12,
    color: colors.muted,
    textAlign: 'center',
  },
  modalActions: {
    flexDirection: 'row',
    gap: 9,
    width: '100%',
    marginTop: 12,
  },
});
