import { StyleSheet } from 'react-native';
import { Tabs } from 'expo-router';
import { BlurView } from 'expo-blur';
import { History, House, ReceiptText, Upload, Users } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, glass } from '@/constants/theme';
import { useAuth } from '@/store/auth';

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const { session } = useAuth();
  const isOwner = session?.role !== 'staff';

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        sceneStyle: { backgroundColor: 'transparent' },
        tabBarActiveTintColor: colors.brand,
        tabBarInactiveTintColor: colors.soft,
        tabBarStyle: {
          height: 62 + insets.bottom,
          paddingBottom: Math.max(insets.bottom, 8),
          paddingTop: 7,
          backgroundColor: 'rgba(255, 255, 255, 0.55)',
          borderTopColor: glass.border,
          borderTopWidth: 1,
          elevation: 0,
        },
        tabBarBackground: () => (
          <BlurView
            tint="light"
            intensity={55}
            style={StyleSheet.absoluteFill}
          />
        ),
        tabBarLabelStyle: {
          fontSize: 10.5,
          fontWeight: '700',
        },
        tabBarHideOnKeyboard: true,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'होम',
          tabBarIcon: ({ color, size }) => <House color={color} size={size - 2} />,
        }}
      />
      <Tabs.Screen
        name="billing"
        options={{
          title: 'बिलिंग',
          tabBarIcon: ({ color, size }) => <ReceiptText color={color} size={size - 2} />,
        }}
      />
      <Tabs.Screen
        name="history"
        options={{
          title: 'इतिहास',
          tabBarIcon: ({ color, size }) => <History color={color} size={size - 2} />,
        }}
      />
      <Tabs.Screen
        name="upload"
        options={{
          title: 'प्रोडक्ट',
          href: isOwner ? undefined : null,
          tabBarIcon: ({ color, size }) => <Upload color={color} size={size - 2} />,
        }}
      />
      <Tabs.Screen
        name="staff"
        options={{
          title: 'स्टाफ',
          href: isOwner ? undefined : null,
          tabBarIcon: ({ color, size }) => <Users color={color} size={size - 2} />,
        }}
      />
    </Tabs>
  );
}
