import { useMemo, useRef, useState } from 'react';
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter, type Href } from 'expo-router';
import * as Sharing from 'expo-sharing';
import QRCode from 'react-native-qrcode-svg';
import ViewShot from 'react-native-view-shot';
import {
  Check,
  CheckCircle2,
  CircleAlert,
  Download,
  Pencil,
  Plus,
  QrCode,
  ReceiptText,
  Search,
  Send,
  ShoppingCart,
  Trash2,
  X,
} from 'lucide-react-native';
import {
  Badge,
  Card,
  Chip,
  EmptyState,
  PrimaryButton,
  QtyStepper,
  SectionHeader,
} from '@/components/ui';
import { LoadingState } from '@/components/LoadingState';
import { BillReceipt } from '@/components/BillReceipt';
import { LiquidBackground } from '@/components/LiquidBackground';
import { shop } from '@/constants/shop';
import { categories, categoryTone, colors, glass, radius } from '@/constants/theme';
import { useShop, type Bill, type PaymentMode, type Product } from '@/store/shop';
import { useAuth } from '@/store/auth';
import { formatINR, isToday } from '@/utils/format';
import { paymentOptions } from '@/utils/payments';

type CartLine = { product: Product; qty: number };

export default function BillingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { ready, products, bills, addBill, upiId, setUpiId } = useShop();
  const { session } = useAuth();

  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('सभी');
  const [cart, setCart] = useState<Record<string, number>>({});
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [discount, setDiscount] = useState('');
  const [mode, setMode] = useState<PaymentMode>('cash');
  const [paymentDone, setPaymentDone] = useState(false);
  const [notice, setNotice] = useState('');
  const [success, setSuccess] = useState<Bill | null>(null);
  const [sharing, setSharing] = useState(false);
  const [shareError, setShareError] = useState('');
  const [shareInfo, setShareInfo] = useState('');
  const [upiEditorOpen, setUpiEditorOpen] = useState(false);
  const [upiDraft, setUpiDraft] = useState('');
  const [upiError, setUpiError] = useState('');
  const shotRef = useRef<ViewShot>(null);

  const todayCount = useMemo(
    () =>
      bills.filter(
        bill =>
          isToday(bill.createdAt) &&
          (session?.role === 'staff' ? bill.staffId === session.staffId : true),
      ).length,
    [bills, session],
  );

  const filteredProducts = useMemo(() => {
    const search = query.trim().toLowerCase();
    return products.filter(product => {
      const matchesCategory = category === 'सभी' || product.category === category;
      const matchesSearch =
        !search ||
        product.name.toLowerCase().includes(search) ||
        product.category.toLowerCase().includes(search);
      return matchesCategory && matchesSearch;
    });
  }, [products, category, query]);

  const cartLines = useMemo<CartLine[]>(() => {
    return Object.keys(cart)
      .map(id => {
        const product = products.find(item => item.id === id);
        if (!product) return null;
        return { product, qty: cart[id] };
      })
      .filter((line): line is CartLine => line !== null);
  }, [cart, products]);

  const subtotal = cartLines.reduce((sum, line) => sum + line.product.price * line.qty, 0);
  const discountValue = Math.min(
    Math.max(Number.parseInt(discount, 10) || 0, 0),
    subtotal,
  );
  const total = subtotal - discountValue;
  const totalQty = cartLines.reduce((sum, line) => sum + line.qty, 0);

  const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
    shop.upiName,
  )}&am=${total.toFixed(2)}&cu=INR&tn=${encodeURIComponent('JVG SmartTech Bill')}`;

  const needsPaymentDone = mode !== 'udhaar';
  const canCreateBill = cartLines.length > 0 && (!needsPaymentDone || paymentDone);

  function addToCart(product: Product) {
    const current = cart[product.id] ?? 0;
    if (product.stock <= 0) {
      setNotice(`${product.name} स्टॉक में नहीं है।`);
      return;
    }
    if (current >= product.stock) {
      setNotice(`${product.name} का सिर्फ ${product.stock} स्टॉक बचा है।`);
      return;
    }
    setNotice('');
    setCart({ ...cart, [product.id]: current + 1 });
  }

  function decrease(id: string) {
    const current = cart[id] ?? 0;
    const next = { ...cart };
    if (current <= 1) {
      delete next[id];
    } else {
      next[id] = current - 1;
    }
    setCart(next);
  }

  function removeLine(id: string) {
    const next = { ...cart };
    delete next[id];
    setCart(next);
  }

  function changeMode(next: PaymentMode) {
    setMode(next);
    setPaymentDone(false);
    setNotice('');
  }

  function openUpiEditor() {
    setUpiDraft(upiId);
    setUpiError('');
    setUpiEditorOpen(true);
  }

  function saveUpiId() {
    const value = upiDraft.trim().replace(/\s/g, '');
    if (!/^[a-zA-Z0-9.\-_]{2,}@[a-zA-Z]{2,}$/.test(value)) {
      setUpiError('सही UPI ID डालिए, जैसे naam@okhdfcbank');
      return;
    }
    setUpiId(value);
    setUpiEditorOpen(false);
    setUpiError('');
  }

  function closeSuccess() {
    setSuccess(null);
    setShareError('');
    setShareInfo('');
    setSharing(false);
  }

  function createBill() {
    if (cartLines.length === 0) {
      setNotice('पहले सामान चुनिए।');
      return;
    }
    const phoneDigits = customerPhone.replace(/\D/g, '');
    if (phoneDigits.length !== 10) {
      setNotice('ग्राहक का 10 अंकों का WhatsApp नंबर डालिए।');
      return;
    }
    if (mode === 'udhaar' && !customerName.trim()) {
      setNotice('उधार बिल के लिए ग्राहक का नाम डालिए।');
      return;
    }
    if (needsPaymentDone && !paymentDone) {
      setNotice('पहले भुगतान Done की पुष्टि कीजिए।');
      return;
    }

    const bill = addBill({
      items: cartLines.map(line => ({
        productId: line.product.id,
        name: line.product.name,
        price: line.product.price,
        qty: line.qty,
        unit: line.product.unit,
      })),
      customerName,
      customerPhone: phoneDigits,
      discount: discountValue,
      paymentMode: mode,
      staffId: session?.staffId ?? 'owner',
      staffName: session?.name ?? 'मालिक',
    });

    setSuccess(bill);
    setShareError('');
    setShareInfo('');
    setCart({});
    setCustomerName('');
    setCustomerPhone('');
    setDiscount('');
    setMode('cash');
    setPaymentDone(false);
    setNotice('');
  }

  async function captureJpg(): Promise<string> {
    const view = shotRef.current;
    if (!view || !view.capture) throw new Error('Receipt is not ready');
    return view.capture();
  }

  async function ensureJpeg(uri: string): Promise<string> {
    if (Platform.OS !== 'web' || !uri.startsWith('data:image/')) return uri;
    if (uri.startsWith('data:image/jpeg')) return uri;

    const doc = (globalThis as { document?: Document }).document;
    if (!doc) return uri;

    return new Promise<string>((resolve, reject) => {
      const img = doc.createElement('img');
      img.onload = () => {
        const canvas = doc.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const context = canvas.getContext('2d');
        if (!context) {
          reject(new Error('Canvas unavailable'));
          return;
        }
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(img, 0, 0);
        resolve(canvas.toDataURL('image/jpeg', 0.95));
      };
      img.onerror = () => reject(new Error('Receipt image failed'));
      img.src = uri;
    });
  }

  function downloadOnWeb(uri: string, number: string) {
    const doc = (globalThis as { document?: Document }).document;
    if (!doc) throw new Error('Download unavailable');
    const link = doc.createElement('a');
    link.href = uri;
    link.download = `JVG-Bill-${number}.jpg`;
    doc.body.appendChild(link);
    link.click();
    link.remove();
  }

  async function shareBill() {
    if (!success) return;
    setSharing(true);
    setShareError('');
    setShareInfo('');
    try {
      const uri = await ensureJpeg(await captureJpg());

      if (Platform.OS === 'web') {
        const webNavigator = (
          globalThis as {
            navigator?: {
              canShare?: (data: unknown) => boolean;
              share?: (data: unknown) => Promise<void>;
            };
          }
        ).navigator;
        const FileCtor = (globalThis as { File?: typeof File }).File;

        if (webNavigator?.share && FileCtor) {
          try {
            const response = await fetch(uri);
            const blob = await response.blob();
            const file = new FileCtor([blob], `JVG-Bill-${success.number}.jpg`, {
              type: 'image/jpeg',
            });
            if (!webNavigator.canShare || webNavigator.canShare({ files: [file] })) {
              await webNavigator.share({
                files: [file],
                title: `बिल ${success.number}`,
              });
              return;
            }
          } catch (error) {
            if ((error as Error).name === 'AbortError') return;
          }
        }

        downloadOnWeb(uri, success.number);
        setShareInfo('JPG डाउनलोड हो गया — WhatsApp में अटैच करके भेजें।');
        return;
      }

      const available = await Sharing.isAvailableAsync();
      if (!available) {
        setShareError('शेयरिंग उपलब्ध नहीं है।');
        return;
      }
      await Sharing.shareAsync(uri, {
        mimeType: 'image/jpeg',
        dialogTitle: `बिल ${success.number} JPG भेजें`,
        UTI: 'public.jpeg',
      });
    } catch {
      setShareError('बिल JPG नहीं बन पाया, दोबारा कोशिश कीजिए।');
    } finally {
      setSharing(false);
    }
  }

  async function downloadBill() {
    if (!success) return;
    setSharing(true);
    setShareError('');
    setShareInfo('');
    try {
      const uri = await ensureJpeg(await captureJpg());
      downloadOnWeb(uri, success.number);
      setShareInfo('JPG डाउनलोड हो गया।');
    } catch {
      setShareError('बिल JPG नहीं बन पाया, दोबारा कोशिश कीजिए।');
    } finally {
      setSharing(false);
    }
  }

  if (!ready) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <LiquidBackground />
        <LoadingState />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <LiquidBackground />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={[styles.content, { paddingBottom: 236 + insets.bottom * 0.4 }]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <View style={styles.headerText}>
              <Text style={styles.title}>नया बिल</Text>
              <Text style={styles.headerSub}>
                बना रहे हैं: {session?.name ?? 'मालिक'}
                {session?.phone ? ` · ${session.phone}` : ''}
              </Text>
            </View>
            <View style={styles.todayPill}>
              <ReceiptText size={13} color={colors.brand} />
              <Text style={styles.todayPillText}>{todayCount} आज</Text>
            </View>
          </View>

          <View style={styles.searchBox}>
            <Search size={17} color={colors.soft} />
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="प्रोडक्ट खोजें…"
              placeholderTextColor={colors.soft}
              style={styles.searchInput}
            />
            {query.length > 0 ? (
              <Pressable onPress={() => setQuery('')} hitSlop={8}>
                <X size={16} color={colors.muted} />
              </Pressable>
            ) : null}
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.chipRow}
          >
            <Chip label="सभी" active={category === 'सभी'} onPress={() => setCategory('सभी')} />
            {categories.map(item => (
              <Chip
                key={item}
                label={item}
                active={category === item}
                onPress={() => setCategory(item)}
              />
            ))}
          </ScrollView>

          {filteredProducts.length === 0 ? (
            <Card>
              <EmptyState
                icon={<Search size={24} color={colors.brand} />}
                title="कोई प्रोडक्ट नहीं"
                body="दूसरा नाम खोजिए या प्रोडक्ट टैब से नया सामान जोड़िए।"
              />
            </Card>
          ) : (
            <View style={styles.productGrid}>
              {filteredProducts.map(product => {
                const qty = cart[product.id] ?? 0;
                const tone = categoryTone[product.category] ?? categoryTone['अन्य'];
                const outOfStock = product.stock <= 0;
                return (
                  <View key={product.id} style={styles.productCard}>
                    <View style={styles.productTop}>
                      <View style={[styles.productTile, { backgroundColor: tone.bg }]}>
                        <Text style={[styles.productInitial, { color: tone.text }]}>
                          {product.name.slice(0, 1)}
                        </Text>
                      </View>
                      {product.stock <= 5 ? (
                        <Badge label="कम स्टॉक" tone="danger" />
                      ) : (
                        <Text style={styles.productStock}>स्टॉक {product.stock}</Text>
                      )}
                    </View>
                    <Text style={styles.productName} numberOfLines={2}>
                      {product.name}
                    </Text>
                    <View style={styles.priceRow}>
                      <Text style={styles.productPrice}>{formatINR(product.price)}</Text>
                      <Text style={styles.productUnit}>/ {product.unit}</Text>
                    </View>
                    {qty > 0 ? (
                      <QtyStepper
                        value={qty}
                        onDecrease={() => decrease(product.id)}
                        onIncrease={() => addToCart(product)}
                      />
                    ) : (
                      <Pressable
                        onPress={() => addToCart(product)}
                        disabled={outOfStock}
                        style={({ pressed }) => [
                          styles.addButton,
                          outOfStock && styles.addButtonDisabled,
                          pressed && !outOfStock && styles.addButtonPressed,
                        ]}
                      >
                        {outOfStock ? (
                          <Text style={styles.addButtonTextMuted}>खत्म</Text>
                        ) : (
                          <>
                            <Plus size={14} color={colors.white} />
                            <Text style={styles.addButtonText}>जोड़ें</Text>
                          </>
                        )}
                      </Pressable>
                    )}
                  </View>
                );
              })}
            </View>
          )}

          <View>
            <SectionHeader title={`बिल कार्ट${totalQty ? ` · ${totalQty}` : ''}`} />
            <Card style={styles.cartCard}>
              {cartLines.length === 0 ? (
                <EmptyState
                  icon={<ShoppingCart size={24} color={colors.brand} />}
                  title="कार्ट खाली है"
                  body="ऊपर से सामान चुनिए।"
                />
              ) : (
                cartLines.map((line, index) => (
                  <View
                    key={line.product.id}
                    style={[
                      styles.cartRow,
                      index !== cartLines.length - 1 && styles.rowDivider,
                    ]}
                  >
                    <View style={styles.cartMain}>
                      <Text style={styles.cartName} numberOfLines={1}>
                        {line.product.name}
                      </Text>
                      <Text style={styles.cartMeta}>
                        {formatINR(line.product.price)} × {line.qty}
                      </Text>
                    </View>
                    <QtyStepper
                      size="sm"
                      value={line.qty}
                      onDecrease={() => decrease(line.product.id)}
                      onIncrease={() => addToCart(line.product)}
                    />
                    <Text style={styles.cartTotal}>
                      {formatINR(line.product.price * line.qty)}
                    </Text>
                    <Pressable
                      onPress={() => removeLine(line.product.id)}
                      hitSlop={8}
                      accessibilityLabel="आइटम हटाएं"
                    >
                      <Trash2 size={16} color={colors.danger} />
                    </Pressable>
                  </View>
                ))
              )}
            </Card>
          </View>

          <View>
            <SectionHeader title="ग्राहक" />
            <Card style={styles.formCard}>
              <View style={styles.inlineFields}>
                <View style={styles.flex}>
                  <Text style={styles.fieldLabel}>ग्राहक का नाम</Text>
                  <TextInput
                    value={customerName}
                    onChangeText={setCustomerName}
                    placeholder="नाम"
                    placeholderTextColor={colors.soft}
                    style={styles.input}
                  />
                </View>
                <View style={styles.flex}>
                  <Text style={styles.fieldLabel}>WhatsApp नंबर</Text>
                  <TextInput
                    value={customerPhone}
                    onChangeText={value =>
                      setCustomerPhone(value.replace(/\D/g, '').slice(0, 10))
                    }
                    placeholder="10 अंक"
                    placeholderTextColor={colors.soft}
                    keyboardType="number-pad"
                    maxLength={10}
                    style={styles.input}
                  />
                </View>
              </View>

              <View style={styles.discountRow}>
                <Text style={styles.fieldLabel}>छूट (₹)</Text>
                <TextInput
                  value={discount}
                  onChangeText={value => setDiscount(value.replace(/[^0-9]/g, ''))}
                  placeholder="0"
                  placeholderTextColor={colors.soft}
                  keyboardType="number-pad"
                  style={styles.discountInput}
                />
              </View>
            </Card>
          </View>

          <View>
            <SectionHeader title="भुगतान" />
            <View style={styles.paymentRow}>
              {paymentOptions.map(option => {
                const active = mode === option.mode;
                return (
                  <Pressable
                    key={option.mode}
                    onPress={() => changeMode(option.mode)}
                    style={[styles.paymentTile, active && styles.paymentTileActive]}
                  >
                    <View
                      style={[
                        styles.paymentCheck,
                        active && styles.paymentCheckActive,
                      ]}
                    >
                      {active ? <Check size={11} color={colors.white} /> : null}
                    </View>
                    <Text
                      style={[
                        styles.paymentLabel,
                        active && styles.paymentLabelActive,
                      ]}
                    >
                      {option.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {cartLines.length > 0 ? (
            <Card style={styles.qrCard}>
              <View style={styles.qrHead}>
                <View style={styles.qrIcon}>
                  <QrCode size={17} color={colors.brand} />
                </View>
                <View style={styles.flex}>
                  <Text style={styles.qrTitle}>UPI QR</Text>
                  <View style={styles.qrSubRow}>
                    <Text style={styles.qrSub} numberOfLines={1}>{upiId}</Text>
                    <Pressable onPress={openUpiEditor} style={styles.upiEditBtn}>
                      <Pencil size={10} color={colors.brandMid} />
                      <Text style={styles.upiEditText}>बदलें</Text>
                    </Pressable>
                  </View>
                </View>
                <Text style={styles.qrAmount}>{formatINR(total)}</Text>
              </View>
              <View style={styles.qrBox}>
                <QRCode
                  value={upiUri}
                  size={168}
                  color={colors.brand}
                  backgroundColor="#ffffff"
                />
              </View>
              <Text style={styles.qrHint}>ग्राहक QR स्कैन करके भुगतान करे</Text>
            </Card>
          ) : null}

          {cartLines.length > 0 && mode !== 'udhaar' ? (
            <Card style={styles.doneCard}>
              <View style={styles.doneInfo}>
                <View style={styles.doneIcon}>
                  <Check size={15} color={colors.brand} />
                </View>
                <View style={styles.flex}>
                  <Text style={styles.doneTitle}>
                    {mode === 'cash' ? 'नकद भुगतान' : 'UPI भुगतान'}
                  </Text>
                  <Text style={styles.doneCaption}>
                    {paymentDone ? 'भुगतान मिल गया' : 'भुगतान मिलने पर Done दबाएं'}
                  </Text>
                </View>
              </View>
              <Pressable
                onPress={() => setPaymentDone(true)}
                style={[styles.doneButton, paymentDone && styles.doneButtonActive]}
              >
                <Check
                  size={14}
                  color={paymentDone ? colors.white : colors.brand}
                />
                <Text
                  style={[
                    styles.doneButtonText,
                    paymentDone && styles.doneButtonTextActive,
                  ]}
                >
                  Done
                </Text>
              </Pressable>
            </Card>
          ) : null}

        </ScrollView>
      </KeyboardAvoidingView>

      <View style={[styles.footer, { paddingBottom: 12 }]}>
        {notice ? (
          <View style={styles.footerNotice}>
            <CircleAlert size={14} color={colors.danger} />
            <Text style={styles.noticeText}>{notice}</Text>
          </View>
        ) : null}
        <View style={styles.footerTotals}>
          <View style={styles.footerLeft}>
            <Text style={styles.footerLabel}>कुल · {totalQty} आइटम</Text>
            {discountValue > 0 ? (
              <Text style={styles.footerDiscount}>
                {formatINR(subtotal)} − {formatINR(discountValue)} छूट
              </Text>
            ) : null}
          </View>
          <Text style={styles.footerAmount}>{formatINR(total)}</Text>
        </View>
        <PrimaryButton
          label={
            cartLines.length === 0
              ? 'सामान चुनें'
              : !canCreateBill
                ? 'पहले Done दबाएं'
                : `बिल बनाएं · ${formatINR(total)}`
          }
          onPress={createBill}
          disabled={!canCreateBill}
          icon={
            canCreateBill ? <ReceiptText size={17} color={colors.white} /> : undefined
          }
        />
      </View>

      <Modal
        visible={success !== null}
        transparent
        animationType="fade"
        onRequestClose={closeSuccess}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <View style={styles.successIcon}>
                <CheckCircle2 size={22} color={colors.brand} />
              </View>
              <View style={styles.flex}>
                <Text style={styles.modalTitle}>बिल तैयार</Text>
                <Text style={styles.modalCaption}>
                  {success?.number} · {formatINR(success?.total ?? 0)} ·{' '}
                  {success?.customerName}
                </Text>
              </View>
              <Pressable onPress={closeSuccess} hitSlop={8}>
                <X size={18} color={colors.muted} />
              </Pressable>
            </View>

            {success ? (
              <ScrollView
                style={styles.receiptScroll}
                contentContainerStyle={styles.receiptScrollContent}
                showsVerticalScrollIndicator={false}
              >
                <ViewShot
                  ref={shotRef}
                  style={styles.shotWrap}
                  options={{
                    format: 'jpg',
                    quality: 0.95,
                    result: Platform.OS === 'web' ? 'data-uri' : 'tmpfile',
                  }}
                >
                  <BillReceipt bill={success} />
                </ViewShot>
              </ScrollView>
            ) : null}

            {shareInfo ? <Text style={styles.shareInfo}>{shareInfo}</Text> : null}
            {shareError ? <Text style={styles.shareError}>{shareError}</Text> : null}

            <PrimaryButton
              label="WhatsApp पर JPG भेजें"
              onPress={shareBill}
              loading={sharing}
              icon={<Send size={16} color={colors.white} />}
            />
            {Platform.OS === 'web' ? (
              <PrimaryButton
                label="JPG डाउनलोड करें"
                tone="ghost"
                onPress={downloadBill}
                disabled={sharing}
                icon={<Download size={16} color={colors.brand} />}
              />
            ) : null}

            <View style={styles.modalLinks}>
              <Pressable
                onPress={() => {
                  closeSuccess();
                  router.push('/history' as Href);
                }}
              >
                <Text style={styles.modalLinkText}>बिल इतिहास देखें</Text>
              </Pressable>
              <Pressable onPress={closeSuccess}>
                <Text style={styles.modalLinkText}>नया बिल</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={upiEditorOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setUpiEditorOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.upiCard}>
            <Text style={styles.upiTitle}>UPI ID बदलें</Text>
            <Text style={styles.upiLabel}>दुकान की UPI ID</Text>
            <TextInput
              value={upiDraft}
              onChangeText={value => {
                setUpiDraft(value);
                setUpiError('');
              }}
              placeholder="naam@okhdfcbank"
              placeholderTextColor={colors.soft}
              autoCapitalize="none"
              autoCorrect={false}
              style={styles.upiInput}
            />
            {upiError ? <Text style={styles.shareError}>{upiError}</Text> : null}
            <View style={styles.upiActions}>
              <PrimaryButton
                label="रद्द करें"
                tone="ghost"
                onPress={() => setUpiEditorOpen(false)}
                style={styles.flex}
              />
              <PrimaryButton
                label="सेव करें"
                onPress={saveUpiId}
                style={styles.flex}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 18,
    paddingTop: 10,
    gap: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  headerText: {
    flex: 1,
    gap: 2,
  },
  headerSub: {
    fontSize: 11,
    color: colors.muted,
  },
  title: {
    fontSize: 23,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.5,
  },
  todayPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.brandSoft,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 999,
  },
  todayPillText: {
    fontSize: 11,
    fontWeight: '800',
    color: colors.brand,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    backgroundColor: glass.fillStrong,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    paddingHorizontal: 13,
    minHeight: 48,
  },
  searchInput: {
    flex: 1,
    fontSize: 14.5,
    color: colors.ink,
    paddingVertical: 10,
  },
  chipRow: {
    gap: 8,
    paddingRight: 4,
    marginTop: -8,
  },
  productGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: -6,
  },
  productCard: {
    flexBasis: '47%',
    flexGrow: 1,
    backgroundColor: glass.fill,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 12,
    gap: 6,
  },
  productTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 6,
    marginBottom: 2,
  },
  productTile: {
    width: 42,
    height: 42,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  productInitial: {
    fontSize: 17,
    fontWeight: '800',
  },
  productStock: {
    fontSize: 9.5,
    fontWeight: '700',
    color: colors.muted,
    paddingTop: 3,
  },
  productName: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.ink,
    lineHeight: 18,
    minHeight: 36,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 3,
  },
  productPrice: {
    fontSize: 14.5,
    fontWeight: '800',
    color: colors.ink,
  },
  productUnit: {
    fontSize: 10,
    color: colors.muted,
    flexShrink: 1,
  },
  addButton: {
    marginTop: 2,
    minHeight: 34,
    borderRadius: 10,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 4,
  },
  addButtonPressed: {
    opacity: 0.85,
  },
  addButtonDisabled: {
    backgroundColor: 'rgba(255,255,255,0.35)',
  },
  addButtonText: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.white,
  },
  addButtonTextMuted: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.soft,
  },
  cartCard: {
    paddingHorizontal: 10,
    paddingVertical: 2,
  },
  cartRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingVertical: 11,
  },
  rowDivider: {
    borderBottomWidth: 1,
    borderBottomColor: glass.line,
  },
  cartMain: {
    flex: 1,
    gap: 2,
  },
  cartName: {
    fontSize: 12.5,
    fontWeight: '700',
    color: colors.ink,
  },
  cartMeta: {
    fontSize: 10.5,
    color: colors.muted,
  },
  cartTotal: {
    fontSize: 12.5,
    fontWeight: '800',
    color: colors.ink,
    minWidth: 48,
    textAlign: 'right',
  },
  formCard: {
    gap: 12,
  },
  inlineFields: {
    flexDirection: 'row',
    gap: 10,
  },
  fieldLabel: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.ink,
    marginBottom: 6,
  },
  input: {
    minHeight: 46,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.input,
    paddingHorizontal: 12,
    fontSize: 13.5,
    color: colors.ink,
  },
  discountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  discountInput: {
    minWidth: 94,
    minHeight: 44,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.input,
    paddingHorizontal: 12,
    fontSize: 15,
    fontWeight: '700',
    color: colors.ink,
    textAlign: 'right',
  },
  paymentRow: {
    flexDirection: 'row',
    gap: 9,
  },
  paymentTile: {
    flex: 1,
    backgroundColor: glass.fill,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.md,
    paddingVertical: 13,
    paddingHorizontal: 10,
    gap: 5,
  },
  paymentTileActive: {
    backgroundColor: colors.brand,
    borderColor: colors.brand,
  },
  paymentCheck: {
    width: 16,
    height: 16,
    borderRadius: 999,
    borderWidth: 1.5,
    borderColor: colors.line,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paymentCheckActive: {
    backgroundColor: colors.accent,
    borderColor: colors.accent,
  },
  paymentLabel: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.ink,
  },
  paymentLabelActive: {
    color: colors.white,
  },
  qrCard: {
    alignItems: 'center',
    gap: 12,
  },
  qrHead: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    width: '100%',
  },
  qrIcon: {
    width: 36,
    height: 36,
    borderRadius: 11,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  qrTitle: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.ink,
  },
  qrSubRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginTop: 2,
  },
  qrSub: {
    flexShrink: 1,
    fontSize: 10.5,
    color: colors.muted,
  },
  upiEditBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: colors.brandSoft,
    borderRadius: 6,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  upiEditText: {
    fontSize: 8.5,
    fontWeight: '800',
    color: colors.brandMid,
  },
  qrAmount: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
  },
  qrBox: {
    padding: 10,
    borderRadius: radius.md,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: glass.border,
  },
  qrHint: {
    fontSize: 10.5,
    color: colors.muted,
  },
  doneCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  doneInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  doneIcon: {
    width: 36,
    height: 36,
    borderRadius: 11,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  doneTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.ink,
  },
  doneCaption: {
    fontSize: 10.5,
    color: colors.muted,
    marginTop: 1,
  },
  doneButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: colors.brand,
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  doneButtonActive: {
    backgroundColor: colors.brand,
  },
  doneButtonText: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.brand,
  },
  doneButtonTextActive: {
    color: colors.white,
  },
  footerNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.dangerSoft,
    borderRadius: 9,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  noticeText: {
    flex: 1,
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.danger,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: glass.fillStrong,
    borderTopWidth: 1,
    borderTopColor: glass.border,
    paddingHorizontal: 18,
    paddingTop: 12,
    gap: 10,
  },
  footerTotals: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  footerLeft: {
    gap: 1,
  },
  footerLabel: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.muted,
  },
  footerDiscount: {
    fontSize: 10.5,
    color: colors.soft,
  },
  footerAmount: {
    fontSize: 21,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.4,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(12, 30, 23, 0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 18,
  },
  modalCard: {
    width: '100%',
    maxWidth: 380,
    maxHeight: '94%',
    backgroundColor: glass.overlay,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 16,
    gap: 10,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  successIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
  },
  modalCaption: {
    fontSize: 10.5,
    color: colors.muted,
    marginTop: 1,
  },
  receiptScroll: {
    maxHeight: 400,
    flexGrow: 0,
    borderRadius: 14,
  },
  receiptScrollContent: {
    alignItems: 'center',
    paddingVertical: 2,
  },
  shotWrap: {
    backgroundColor: '#ffffff',
  },
  shareInfo: {
    fontSize: 10.5,
    fontWeight: '600',
    color: colors.brandMid,
    textAlign: 'center',
  },
  shareError: {
    fontSize: 10.5,
    fontWeight: '600',
    color: colors.danger,
    textAlign: 'center',
  },
  modalLinks: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
    paddingTop: 2,
  },
  modalLinkText: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.brandMid,
  },
  upiCard: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: glass.overlay,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 20,
    gap: 9,
  },
  upiTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.ink,
  },
  upiLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.muted,
    marginTop: 2,
  },
  upiInput: {
    minHeight: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.input,
    paddingHorizontal: 12,
    fontSize: 14,
    color: colors.ink,
  },
  upiActions: {
    flexDirection: 'row',
    gap: 9,
    marginTop: 6,
  },
});
