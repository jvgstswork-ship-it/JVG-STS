import { useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Boxes,
  CheckCircle2,
  CircleAlert,
  Layers,
  PackagePlus,
  Plus,
  Search,
  Trash2,
  TrendingUp,
  X,
} from 'lucide-react-native';
import {
  Badge,
  Card,
  Chip,
  EmptyState,
  PrimaryButton,
  QtyStepper,
  SectionHeader,
} from '@/components/ui';
import { LoadingState } from '@/components/LoadingState';
import { LiquidBackground } from '@/components/LiquidBackground';
import { categories, categoryTone, colors, glass, radius } from '@/constants/theme';
import { useShop, type Product } from '@/store/shop';
import { formatINR } from '@/utils/format';

const units = ['पीस', 'पैकेट', 'सेट', 'बॉक्स', 'सेवा', 'किलो', 'ग्राम', 'लीटर', 'बोतल'];

export default function UploadScreen() {
  const { ready, products, addProduct, updateStock, deleteProduct } = useShop();

  const [name, setName] = useState('');
  const [category, setCategory] = useState(categories[0]);
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');
  const [unit, setUnit] = useState(units[0]);
  const [formError, setFormError] = useState('');
  const [savedMessage, setSavedMessage] = useState('');

  const [query, setQuery] = useState('');
  const [lowOnly, setLowOnly] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);

  const lowStockCount = products.filter(product => product.stock <= 5).length;
  const stockValue = products
    .filter(product => product.category !== 'बैंकिंग सेवा')
    .reduce((sum, product) => sum + product.price * product.stock, 0);

  const filteredProducts = useMemo(() => {
    const search = query.trim().toLowerCase();
    return products.filter(product => {
      if (lowOnly && product.stock > 5) return false;
      if (!search) return true;
      return (
        product.name.toLowerCase().includes(search) ||
        product.category.toLowerCase().includes(search)
      );
    });
  }, [products, lowOnly, query]);

  function handleSubmit() {
    const trimmed = name.trim();
    const priceValue = Number.parseInt(price, 10);
    const stockValueInput = Number.parseInt(stock === '' ? '0' : stock, 10);

    if (!trimmed) {
      setFormError('प्रोडक्ट का नाम लिखिए।');
      return;
    }
    if (!Number.isFinite(priceValue) || priceValue <= 0) {
      setFormError('बिक्री कीमत 0 से बड़ी होनी चाहिए।');
      return;
    }
    if (!Number.isFinite(stockValueInput) || stockValueInput < 0) {
      setFormError('स्टॉक की सही संख्या भरिए।');
      return;
    }

    addProduct({
      name: trimmed,
      category,
      price: priceValue,
      stock: stockValueInput,
      unit,
    });
    setSavedMessage(`${trimmed} दुकान के कैटलॉग में जुड़ गया।`);
    setFormError('');
    setName('');
    setPrice('');
    setStock('');
    setCategory(categories[0]);
    setUnit(units[0]);
  }

  if (!ready) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <LiquidBackground />
        <LoadingState label="प्रोडक्ट कैटलॉग खुल रहा है…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <LiquidBackground />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <View style={styles.headerText}>
              <Text style={styles.title}>प्रोडक्ट और स्टॉक</Text>
              <Text style={styles.subtitle}>
                नई एक्सेसरी या बैंकिंग सेवा जोड़ें और स्टॉक अपडेट रखें।
              </Text>
            </View>
            <View style={styles.headerIcon}>
              <PackagePlus size={20} color={colors.brand} />
            </View>
          </View>

          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <Boxes size={15} color={colors.info} />
              <Text style={styles.statValue}>{products.length}</Text>
              <Text style={styles.statLabel}>कुल प्रोडक्ट</Text>
            </View>
            <View style={styles.statCard}>
              <TrendingUp size={15} color={colors.brandMid} />
              <Text style={styles.statValue}>{formatINR(stockValue)}</Text>
              <Text style={styles.statLabel}>स्टॉक की वैल्यू</Text>
            </View>
            <View style={styles.statCard}>
              <CircleAlert size={15} color={colors.danger} />
              <Text style={styles.statValue}>{lowStockCount}</Text>
              <Text style={styles.statLabel}>कम स्टॉक</Text>
            </View>
          </View>

          <View>
            <SectionHeader
              title="नया प्रोडक्ट जोड़ें"
              caption="कीमत और स्टॉक ध्यान से भरें"
            />
            <Card style={styles.formCard}>
              <View>
                <Text style={styles.fieldLabel}>प्रोडक्ट का नाम</Text>
                <TextInput
                  value={name}
                  onChangeText={value => {
                    setName(value);
                    setFormError('');
                  }}
                  placeholder="जैसे: Type-C डेटा केबल"
                  placeholderTextColor={colors.soft}
                  style={styles.input}
                />
              </View>

              <View>
                <Text style={styles.fieldLabel}>श्रेणी</Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.categoryRow}
                >
                  {categories.map(item => (
                    <Chip
                      key={item}
                      label={item}
                      active={category === item}
                      onPress={() => setCategory(item)}
                    />
                  ))}
                </ScrollView>
              </View>

              <View style={styles.inlineFields}>
                <View style={styles.flex}>
                  <Text style={styles.fieldLabel}>बिक्री कीमत (₹)</Text>
                  <TextInput
                    value={price}
                    onChangeText={value => {
                      setPrice(value.replace(/[^0-9]/g, ''));
                      setFormError('');
                    }}
                    placeholder="0"
                    placeholderTextColor={colors.soft}
                    keyboardType="number-pad"
                    style={styles.input}
                  />
                </View>
                <View style={styles.flex}>
                  <Text style={styles.fieldLabel}>स्टॉक</Text>
                  <TextInput
                    value={stock}
                    onChangeText={value => {
                      setStock(value.replace(/[^0-9]/g, ''));
                      setFormError('');
                    }}
                    placeholder="0"
                    placeholderTextColor={colors.soft}
                    keyboardType="number-pad"
                    style={styles.input}
                  />
                </View>
              </View>

              <View>
                <Text style={styles.fieldLabel}>इकाई</Text>
                <View style={styles.unitRow}>
                  {units.map(item => (
                    <Chip
                      key={item}
                      label={item}
                      active={unit === item}
                      onPress={() => setUnit(item)}
                    />
                  ))}
                </View>
              </View>

              {formError ? (
                <View style={styles.errorBox}>
                  <CircleAlert size={14} color={colors.danger} />
                  <Text style={styles.errorText}>{formError}</Text>
                </View>
              ) : null}

              <PrimaryButton
                label="प्रोडक्ट जोड़ें"
                onPress={handleSubmit}
                icon={<Plus size={17} color={colors.white} />}
              />
            </Card>
          </View>

          {savedMessage ? (
            <View style={styles.successBox}>
              <CheckCircle2 size={17} color={colors.brandMid} />
              <Text style={styles.successText}>{savedMessage}</Text>
              <Pressable onPress={() => setSavedMessage('')} hitSlop={8}>
                <X size={15} color={colors.brandMid} />
              </Pressable>
            </View>
          ) : null}

          <View>
            <SectionHeader
              title="दुकान का कैटलॉग"
              caption={`${filteredProducts.length} प्रोडक्ट दिख रहे हैं`}
            />
            <View style={styles.toolbar}>
              <View style={styles.searchBox}>
                <Search size={16} color={colors.soft} />
                <TextInput
                  value={query}
                  onChangeText={setQuery}
                  placeholder="प्रोडक्ट खोजें…"
                  placeholderTextColor={colors.soft}
                  style={styles.searchInput}
                />
                {query.length > 0 ? (
                  <Pressable onPress={() => setQuery('')} hitSlop={8}>
                    <X size={15} color={colors.muted} />
                  </Pressable>
                ) : null}
              </View>
              <Pressable
                onPress={() => setLowOnly(current => !current)}
                style={[styles.lowToggle, lowOnly && styles.lowToggleActive]}
              >
                <Layers size={14} color={lowOnly ? colors.white : colors.muted} />
                <Text
                  style={[styles.lowToggleText, lowOnly && styles.lowToggleTextActive]}
                >
                  कम स्टॉक
                </Text>
              </Pressable>
            </View>

            {filteredProducts.length === 0 ? (
              <Card>
                <EmptyState
                  icon={<Boxes size={24} color={colors.brand} />}
                  title="कोई प्रोडक्ट नहीं मिला"
                  body="फ़िल्टर बदलिए या ऊपर के फॉर्म से नया प्रोडक्ट जोड़िए।"
                />
              </Card>
            ) : (
              <View style={styles.productList}>
                {filteredProducts.map(product => {
                  const tone = categoryTone[product.category] ?? categoryTone['अन्य'];
                  const low = product.stock <= 5;
                  return (
                    <Card key={product.id} style={styles.productRow}>
                      <View style={[styles.productTile, { backgroundColor: tone.bg }]}>
                        <Text style={[styles.productInitial, { color: tone.text }]}>
                          {product.name.slice(0, 1)}
                        </Text>
                      </View>
                      <View style={styles.productInfo}>
                        <Text style={styles.productName} numberOfLines={1}>
                          {product.name}
                        </Text>
                        <Text style={styles.productMeta}>
                          {formatINR(product.price)} / {product.unit} · {product.category}
                        </Text>
                        <View style={styles.stockLine}>
                          {low ? (
                            <Badge label={`सिर्फ ${product.stock} बचे`} tone="danger" />
                          ) : (
                            <Badge label={`स्टॉक ${product.stock}`} tone="brand" />
                          )}
                        </View>
                      </View>
                      <View style={styles.productActions}>
                        <QtyStepper
                          size="sm"
                          value={product.stock}
                          onDecrease={() => updateStock(product.id, -1)}
                          onIncrease={() => updateStock(product.id, 1)}
                        />
                        <View style={styles.rowButtons}>
                          <Pressable
                            onPress={() => updateStock(product.id, 10)}
                            style={styles.quickAdd}
                            accessibilityLabel="10 स्टॉक जोड़ें"
                          >
                            <Text style={styles.quickAddText}>+10</Text>
                          </Pressable>
                          <Pressable
                            onPress={() => setDeleteTarget(product)}
                            hitSlop={6}
                            accessibilityLabel="प्रोडक्ट हटाएं"
                          >
                            <Trash2 size={15} color={colors.danger} />
                          </Pressable>
                        </View>
                      </View>
                    </Card>
                  );
                })}
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={deleteTarget !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setDeleteTarget(null)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.deleteIcon}>
              <Trash2 size={24} color={colors.danger} />
            </View>
            <Text style={styles.modalTitle}>प्रोडक्ट हटाना है?</Text>
            <Text style={styles.modalBody}>{deleteTarget?.name}</Text>
            <Text style={styles.modalWarn}>
              पुराने बिलों में इसका रिकॉर्ड बना रहेगा।
            </Text>
            <View style={styles.modalActions}>
              <PrimaryButton
                label="रद्द करें"
                tone="ghost"
                onPress={() => setDeleteTarget(null)}
                style={styles.flex}
              />
              <PrimaryButton
                label="हटाएं"
                tone="danger"
                onPress={() => {
                  if (deleteTarget) deleteProduct(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                style={styles.flex}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 18,
    paddingTop: 10,
    paddingBottom: 32,
    gap: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 10,
  },
  headerText: {
    flex: 1,
    gap: 4,
  },
  title: {
    fontSize: 23,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 12.5,
    color: colors.muted,
    lineHeight: 18,
  },
  headerIcon: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 9,
  },
  statCard: {
    flex: 1,
    backgroundColor: glass.fill,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 12,
    gap: 3,
  },
  statValue: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.2,
  },
  statLabel: {
    fontSize: 9.5,
    color: colors.muted,
  },
  formCard: {
    gap: 12,
  },
  fieldLabel: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.ink,
    marginBottom: 6,
  },
  input: {
    minHeight: 46,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.input,
    paddingHorizontal: 12,
    fontSize: 13.5,
    color: colors.ink,
  },
  categoryRow: {
    gap: 7,
    paddingRight: 4,
    paddingVertical: 1,
  },
  inlineFields: {
    flexDirection: 'row',
    gap: 10,
  },
  unitRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.dangerSoft,
    borderRadius: 10,
    padding: 10,
  },
  errorText: {
    flex: 1,
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.danger,
  },
  successBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.brandSoft,
    borderRadius: radius.md,
    padding: 12,
    marginTop: -6,
  },
  successText: {
    flex: 1,
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.brand,
  },
  toolbar: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 10,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: glass.fillStrong,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    paddingHorizontal: 12,
    minHeight: 44,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: colors.ink,
    paddingVertical: 8,
  },
  lowToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    backgroundColor: glass.fillStrong,
  },
  lowToggleActive: {
    backgroundColor: colors.brand,
    borderColor: colors.brand,
  },
  lowToggleText: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.muted,
  },
  lowToggleTextActive: {
    color: colors.white,
  },
  productList: {
    gap: 9,
  },
  productRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 12,
  },
  productTile: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  productInitial: {
    fontSize: 17,
    fontWeight: '800',
  },
  productInfo: {
    flex: 1,
    gap: 2,
  },
  productName: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.ink,
  },
  productMeta: {
    fontSize: 10,
    color: colors.muted,
  },
  stockLine: {
    marginTop: 3,
  },
  productActions: {
    alignItems: 'flex-end',
    gap: 6,
  },
  rowButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  quickAdd: {
    backgroundColor: colors.accentSoft,
    borderRadius: 7,
    paddingHorizontal: 7,
    paddingVertical: 3,
  },
  quickAddText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#8a5a12',
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(12, 30, 23, 0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 380,
    backgroundColor: glass.overlay,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.xl,
    padding: 22,
    alignItems: 'center',
    gap: 6,
  },
  deleteIcon: {
    width: 58,
    height: 58,
    borderRadius: 20,
    backgroundColor: colors.dangerSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
  },
  modalBody: {
    fontSize: 12,
    color: colors.muted,
    textAlign: 'center',
  },
  modalWarn: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.danger,
    marginTop: 2,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 9,
    width: '100%',
    marginTop: 12,
  },
});
