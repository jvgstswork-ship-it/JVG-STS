import { useMemo, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  BadgeCheck,
  ChevronDown,
  ChevronUp,
  Lock,
  Phone,
  ReceiptText,
  Search,
  Trash2,
  Wallet,
  X,
} from 'lucide-react-native';
import {
  Badge,
  Card,
  Chip,
  EmptyState,
  PrimaryButton,
  SectionHeader,
} from '@/components/ui';
import { LoadingState } from '@/components/LoadingState';
import { LiquidBackground } from '@/components/LiquidBackground';
import { colors, glass, radius } from '@/constants/theme';
import { useShop, type Bill } from '@/store/shop';
import { useAuth } from '@/store/auth';
import { formatDay, formatINR, formatTime } from '@/utils/format';
import { paymentMeta } from '@/utils/payments';

type Filter = 'all' | 'cash' | 'upi' | 'udhaar' | 'pending';

const filterOptions: { key: Filter; label: string }[] = [
  { key: 'all', label: 'सभी' },
  { key: 'cash', label: 'नकद' },
  { key: 'upi', label: 'UPI' },
  { key: 'udhaar', label: 'उधार' },
  { key: 'pending', label: 'बाकी' },
];

export default function HistoryScreen() {
  const { ready, bills, settleBill, deleteBill } = useShop();
  const { session } = useAuth();
  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Bill | null>(null);

  const isOwner = session?.role !== 'staff';
  const scopedBills = useMemo(
    () =>
      isOwner ? bills : bills.filter(bill => bill.staffId === session?.staffId),
    [bills, isOwner, session?.staffId],
  );

  const outstanding = useMemo(
    () =>
      scopedBills
        .filter(bill => bill.paymentMode === 'udhaar' && !bill.settled)
        .reduce((sum, bill) => sum + bill.total, 0),
    [scopedBills],
  );

  const collected = useMemo(
    () => scopedBills.reduce((sum, bill) => sum + (bill.settled ? bill.total : 0), 0),
    [scopedBills],
  );

  const filteredBills = useMemo(() => {
    const search = query.trim().toLowerCase();
    return scopedBills
      .filter(bill => {
        if (filter === 'pending') return bill.paymentMode === 'udhaar' && !bill.settled;
        if (filter !== 'all' && bill.paymentMode !== filter) return false;
        if (!search) return true;
        return (
          bill.customerName.toLowerCase().includes(search) ||
          bill.number.toLowerCase().includes(search) ||
          bill.customerPhone.includes(search) ||
          bill.items.some(item => item.name.toLowerCase().includes(search))
        );
      })
      .sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
  }, [scopedBills, filter, query]);

  const filteredTotal = filteredBills.reduce((sum, bill) => sum + bill.total, 0);

  if (!ready) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <LiquidBackground />
        <LoadingState label="बिल इतिहास खुल रहा है…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <LiquidBackground />
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.headerText}>
            <Text style={styles.title}>बिल इतिहास</Text>
            <Text style={styles.subtitle}>
              हर लेन-देन का पूरा रिकॉर्ड, एक ही जगह।
            </Text>
          </View>
          <View style={styles.countPill}>
            <Text style={styles.countText}>
              {scopedBills.length} {isOwner ? 'कुल बिल' : 'मेरे बिल'}
            </Text>
          </View>
        </View>

        <View style={styles.summaryRow}>
          <View style={[styles.summaryCard, styles.summaryBrand]}>
            <View style={styles.summaryIconBrand}>
              <Wallet size={16} color={colors.brand} />
            </View>
            <Text style={styles.summaryLabelDark}>कुल वसूली</Text>
            <Text style={styles.summaryValueDark}>{formatINR(collected)}</Text>
          </View>
          <View style={styles.summaryCard}>
            <View style={styles.summaryIconDanger}>
              <ReceiptText size={16} color={colors.danger} />
            </View>
            <Text style={styles.summaryLabel}>उधार बाकी</Text>
            <Text style={styles.summaryValue}>{formatINR(outstanding)}</Text>
          </View>
        </View>

        <View>
          <SectionHeader
            title="सभी बिल"
            caption={`${filteredBills.length} नतीजे · ${formatINR(filteredTotal)}`}
          />
          <View style={styles.searchBox}>
            <Search size={17} color={colors.soft} />
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="नाम, बिल नंबर या सामान खोजें…"
              placeholderTextColor={colors.soft}
              style={styles.searchInput}
            />
            {query.length > 0 ? (
              <Pressable onPress={() => setQuery('')} hitSlop={8}>
                <X size={16} color={colors.muted} />
              </Pressable>
            ) : null}
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filterRow}
          >
            {filterOptions.map(option => (
              <Chip
                key={option.key}
                label={option.label}
                active={filter === option.key}
                onPress={() => setFilter(option.key)}
              />
            ))}
          </ScrollView>

          {filteredBills.length === 0 ? (
            <Card>
              <EmptyState
                icon={<ReceiptText size={24} color={colors.brand} />}
                title="कोई बिल नहीं मिला"
                body="फ़िल्टर बदलिए, दूसरा नाम खोजिए या बिलिंग टैब से नया बिल बनाइए।"
              />
            </Card>
          ) : (
            <View style={styles.billList}>
              {filteredBills.map(bill => {
                const meta = paymentMeta(bill.paymentMode, bill.settled);
                const expanded = expandedId === bill.id;
                const pending = bill.paymentMode === 'udhaar' && !bill.settled;
                return (
                  <Card key={bill.id} style={styles.billCard}>
                    <Pressable
                      onPress={() => setExpandedId(expanded ? null : bill.id)}
                      style={styles.billHeader}
                    >
                      <View style={styles.billHeaderTop}>
                        <View style={styles.billHeaderText}>
                          <Text style={styles.billCustomer} numberOfLines={1}>
                            {bill.customerName}
                          </Text>
                          <Text style={styles.billMeta}>
                            {bill.number} · {formatDay(bill.createdAt)},{' '}
                            {formatTime(bill.createdAt)}
                            {isOwner ? ` · ${bill.staffName}` : ''}
                          </Text>
                        </View>
                        <View style={styles.billAmountWrap}>
                          <Text style={styles.billAmount}>{formatINR(bill.total)}</Text>
                          <Badge label={meta.label} tone={meta.tone} />
                        </View>
                      </View>
                      <View style={styles.billFooterRow}>
                        <Text style={styles.itemCount}>
                          {bill.items.length} आइटम
                          {bill.discount > 0 ? ` · ${formatINR(bill.discount)} छूट` : ''}
                        </Text>
                        {expanded ? (
                          <ChevronUp size={16} color={colors.muted} />
                        ) : (
                          <ChevronDown size={16} color={colors.muted} />
                        )}
                      </View>
                    </Pressable>

                    {expanded ? (
                      <View style={styles.expanded}>
                        <View style={styles.detailDivider} />
                        {bill.customerPhone ? (
                          <View style={styles.phoneRow}>
                            <Phone size={12} color={colors.muted} />
                            <Text style={styles.phoneText}>{bill.customerPhone}</Text>
                          </View>
                        ) : null}
                        {bill.items.map(item => (
                          <View key={`${bill.id}-${item.productId}`} style={styles.itemRow}>
                            <View style={styles.flex}>
                              <Text style={styles.itemName} numberOfLines={1}>
                                {item.name}
                              </Text>
                              <Text style={styles.itemMeta}>
                                {formatINR(item.price)} × {item.qty} {item.unit}
                              </Text>
                            </View>
                            <Text style={styles.itemTotal}>
                              {formatINR(item.price * item.qty)}
                            </Text>
                          </View>
                        ))}
                        <View style={styles.totalsBox}>
                          <View style={styles.totalRow}>
                            <Text style={styles.totalLabel}>सब-टोटल</Text>
                            <Text style={styles.totalValue}>{formatINR(bill.subtotal)}</Text>
                          </View>
                          {bill.discount > 0 ? (
                            <View style={styles.totalRow}>
                              <Text style={styles.totalLabel}>छूट</Text>
                              <Text style={styles.totalValue}>
                                − {formatINR(bill.discount)}
                              </Text>
                            </View>
                          ) : null}
                          <View style={styles.totalRow}>
                            <Text style={styles.grandLabel}>कुल राशि</Text>
                            <Text style={styles.grandValue}>{formatINR(bill.total)}</Text>
                          </View>
                        </View>

                        <View style={styles.actionsRow}>
                          {pending && isOwner ? (
                            <PrimaryButton
                              label="बकाया चुकता करें"
                              tone="accent"
                              onPress={() => settleBill(bill.id)}
                              icon={<BadgeCheck size={16} color={colors.brand} />}
                              style={styles.flex}
                            />
                          ) : (
                            <View style={styles.settledNote}>
                              <BadgeCheck size={15} color={colors.brandMid} />
                              <Text style={styles.settledText}>
                                {pending
                                  ? 'उधार बाकी — ओनर लॉगिन से चुकता करें'
                                  : bill.paymentMode === 'udhaar'
                                    ? 'यह उधार चुकता हो चुका है'
                                    : 'भुगतान पूरा मिल गया'}
                              </Text>
                            </View>
                          )}
                          {isOwner ? (
                            <Pressable
                              onPress={() => setDeleteTarget(bill)}
                              style={styles.deleteButton}
                              accessibilityLabel="बिल हटाएं"
                            >
                              <Trash2 size={17} color={colors.danger} />
                            </Pressable>
                          ) : null}
                        </View>
                      </View>
                    ) : null}
                  </Card>
                );
              })}
            </View>
          )}
        </View>

        <View style={styles.footerNote}>
          {isOwner ? (
            <Text style={styles.footerText}>
              बिल हटाने से रिकॉर्ड से गायब हो जाएगा, स्टॉक वापस नहीं जुड़ेगा।
            </Text>
          ) : (
            <View style={styles.staffNote}>
              <Lock size={12} color={colors.muted} />
              <Text style={styles.footerText}>
                यहाँ सिर्फ आपके बनाए बिल दिखते हैं। बदलाव सिर्फ ओनर कर सकते हैं।
              </Text>
            </View>
          )}
        </View>
      </ScrollView>

      <Modal
        visible={deleteTarget !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setDeleteTarget(null)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.deleteIcon}>
              <Trash2 size={24} color={colors.danger} />
            </View>
            <Text style={styles.modalTitle}>बिल हटाना है?</Text>
            <Text style={styles.modalBody}>
              {deleteTarget
                ? `${deleteTarget.number} · ${deleteTarget.customerName} · ${formatINR(
                    deleteTarget.total,
                  )}`
                : ''}
            </Text>
            <Text style={styles.modalWarn}>
              यह कार्रवाई वापस नहीं होगी।
            </Text>
            <View style={styles.modalActions}>
              <PrimaryButton
                label="रद्द करें"
                tone="ghost"
                onPress={() => setDeleteTarget(null)}
                style={styles.flex}
              />
              <PrimaryButton
                label="हटाएं"
                tone="danger"
                onPress={() => {
                  if (deleteTarget) deleteBill(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                style={styles.flex}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 18,
    paddingTop: 10,
    paddingBottom: 32,
    gap: 18,
  },
  staffNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 10,
  },
  headerText: {
    flex: 1,
    gap: 4,
  },
  title: {
    fontSize: 23,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 12.5,
    color: colors.muted,
    lineHeight: 18,
  },
  countPill: {
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: 999,
  },
  countText: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.muted,
  },
  summaryRow: {
    flexDirection: 'row',
    gap: 10,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: glass.fill,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 14,
    gap: 2,
  },
  summaryBrand: {
    backgroundColor: colors.brand,
    borderColor: colors.brand,
  },
  summaryIconBrand: {
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 7,
  },
  summaryIconDanger: {
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: colors.dangerSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 7,
  },
  summaryLabel: {
    fontSize: 10.5,
    fontWeight: '600',
    color: colors.muted,
  },
  summaryLabelDark: {
    fontSize: 10.5,
    fontWeight: '600',
    color: '#b8d6c7',
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.3,
  },
  summaryValueDark: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.white,
    letterSpacing: -0.3,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    backgroundColor: glass.fillStrong,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: glass.border,
    paddingHorizontal: 13,
    minHeight: 46,
    marginBottom: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 13.5,
    color: colors.ink,
    paddingVertical: 9,
  },
  filterRow: {
    gap: 8,
    paddingBottom: 12,
    paddingRight: 4,
  },
  billList: {
    gap: 10,
  },
  billCard: {
    padding: 0,
    overflow: 'hidden',
  },
  billHeader: {
    padding: 14,
  },
  billHeaderTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 10,
  },
  billHeaderText: {
    flex: 1,
    gap: 3,
  },
  billCustomer: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.ink,
  },
  billMeta: {
    fontSize: 10.5,
    color: colors.muted,
  },
  billAmountWrap: {
    alignItems: 'flex-end',
    gap: 4,
  },
  billAmount: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
  },
  billFooterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 9,
  },
  itemCount: {
    fontSize: 10.5,
    color: colors.muted,
  },
  expanded: {
    paddingHorizontal: 14,
    paddingBottom: 14,
    gap: 8,
  },
  detailDivider: {
    height: 1,
    backgroundColor: glass.line,
    marginBottom: 3,
  },
  phoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 2,
  },
  phoneText: {
    fontSize: 11,
    color: colors.muted,
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 3,
  },
  itemName: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.ink,
  },
  itemMeta: {
    fontSize: 10,
    color: colors.muted,
    marginTop: 1,
  },
  itemTotal: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.ink,
  },
  totalsBox: {
    backgroundColor: '#faf8f2',
    borderRadius: 12,
    padding: 11,
    gap: 5,
    marginTop: 4,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: 11,
    color: colors.muted,
  },
  totalValue: {
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.ink,
  },
  grandLabel: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.ink,
  },
  grandValue: {
    fontSize: 13.5,
    fontWeight: '800',
    color: colors.ink,
  },
  actionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    marginTop: 4,
  },
  settledNote: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  settledText: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.brandMid,
  },
  deleteButton: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: glass.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: glass.fillStrong,
  },
  footerNote: {
    paddingHorizontal: 4,
  },
  footerText: {
    fontSize: 10.5,
    color: colors.soft,
    textAlign: 'center',
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(12, 30, 23, 0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 380,
    backgroundColor: glass.overlay,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.xl,
    padding: 22,
    alignItems: 'center',
    gap: 6,
  },
  deleteIcon: {
    width: 58,
    height: 58,
    borderRadius: 20,
    backgroundColor: colors.dangerSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
  },
  modalBody: {
    fontSize: 12,
    color: colors.muted,
    textAlign: 'center',
  },
  modalWarn: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.danger,
    marginTop: 2,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 9,
    width: '100%',
    marginTop: 12,
  },
});
