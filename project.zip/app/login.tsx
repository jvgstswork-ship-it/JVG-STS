import { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  BadgeCheck,
  CheckCircle2,
  ChevronLeft,
  CircleAlert,
  KeyRound,
  Lock,
  Phone,
  ShieldCheck,
  Store,
  User,
  UserCog,
  Users,
} from 'lucide-react-native';
import { Field, PrimaryButton } from '@/components/ui';
import { LiquidBackground } from '@/components/LiquidBackground';
import { glass, colors, radius, shadow } from '@/constants/theme';
import { useAuth } from '@/store/auth';
import { useShop } from '@/store/shop';
import { initials } from '@/utils/format';

type Mode = 'owner' | 'staff';

export default function LoginScreen() {
  const { hasOwner, setupOwner, signInOwner, resetOwnerPassword, signInStaff } =
    useAuth();
  const { staff } = useShop();

  const [mode, setMode] = useState<Mode>('owner');
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [staffPhone, setStaffPhone] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [forgotOpen, setForgotOpen] = useState(false);
  const [resetPhone, setResetPhone] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  function handleSetup() {
    if (password !== confirmPassword) {
      setError('दोनों पासवर्ड एक जैसे होने चाहिए।');
      return;
    }
    const result = setupOwner(ownerName, ownerPhone, password);
    setError(result ?? '');
  }

  function handleOwnerSignIn() {
    setError(signInOwner(ownerPhone, password) ?? '');
  }

  function handleStaffSignIn() {
    setError(signInStaff(staffPhone) ?? '');
  }

  function handleResetPassword() {
    if (newPassword !== confirmNewPassword) {
      setError('दोनों नए पासवर्ड एक जैसे होने चाहिए।');
      return;
    }
    const result = resetOwnerPassword(resetPhone, newPassword);
    if (result) {
      setError(result);
      return;
    }
    setError('');
    setPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
    setForgotOpen(false);
    setInfo('पासवर्ड बदल गया है। अब नए पासवर्ड से लॉगिन कीजिए।');
  }

  function openForgotPassword() {
    setForgotOpen(true);
    setResetPhone(ownerPhone);
    setError('');
    setInfo('');
    setNewPassword('');
    setConfirmNewPassword('');
  }

  function closeForgotPassword() {
    setForgotOpen(false);
    setError('');
  }

  function switchMode(next: Mode) {
    setMode(next);
    setError('');
    setInfo('');
    setForgotOpen(false);
  }

  const errorBox = error ? (
    <View style={styles.errorBox}>
      <CircleAlert size={14} color={colors.danger} />
      <Text style={styles.errorText}>{error}</Text>
    </View>
  ) : null;

  const infoBox = info ? (
    <View style={styles.infoBox}>
      <CheckCircle2 size={14} color={colors.brandMid} />
      <Text style={styles.infoText}>{info}</Text>
    </View>
  ) : null;

  const staffCard = (
    <View style={styles.card}>
      <View style={styles.cardHead}>
        <View style={styles.cardIcon}>
          <Users size={18} color={colors.brand} />
        </View>
        <View style={styles.flex}>
          <Text style={styles.cardTitle}>स्टाफ लॉगिन</Text>
          <Text style={styles.cardCaption}>
            ओनर द्वारा जोड़ा गया मोबाइल नंबर डालिए
          </Text>
        </View>
      </View>

      <Field
        label="मोबाइल नंबर"
        value={staffPhone}
        onChangeText={value => {
          setStaffPhone(value.replace(/\D/g, '').slice(0, 10));
          setError('');
        }}
        placeholder="10 अंकों का नंबर"
        keyboardType="number-pad"
        maxLength={10}
        hint="पासवर्ड की जरूरत नहीं — सिर्फ रजिस्टर्ड नंबर।"
      />

      {errorBox}

      <PrimaryButton
        label="स्टाफ के रूप में लॉगिन"
        onPress={handleStaffSignIn}
        icon={<BadgeCheck size={16} color={colors.white} />}
      />

      {staff.length > 0 ? (
        <View style={styles.staffHint}>
          <Text style={styles.staffHintTitle}>रजिस्टर्ड स्टाफ</Text>
          {staff.map(member => (
            <View key={member.id} style={styles.staffRow}>
              <View style={styles.staffAvatar}>
                <Text style={styles.staffAvatarText}>{initials(member.name)}</Text>
              </View>
              <Text style={styles.staffName} numberOfLines={1}>
                {member.name}
              </Text>
              <View style={styles.staffPhoneRow}>
                <Phone size={10} color={colors.muted} />
                <Text style={styles.staffPhone}>{member.phone}</Text>
              </View>
            </View>
          ))}
        </View>
      ) : (
        <Text style={styles.note}>
          अभी कोई स्टाफ नहीं जुड़ा है। ओनर लॉगिन करके स्टाफ टैब से जोड़िए।
        </Text>
      )}
    </View>
  );

  const ownerSignInCard = (
    <View style={styles.card}>
      <View style={styles.cardHead}>
        <View style={styles.cardIcon}>
          <UserCog size={18} color={colors.brand} />
        </View>
        <View style={styles.flex}>
          <Text style={styles.cardTitle}>ओनर लॉगिन</Text>
          <Text style={styles.cardCaption}>
            मोबाइल नंबर और अपना पासवर्ड डालिए
          </Text>
        </View>
      </View>

      <Field
        label="मोबाइल नंबर"
        value={ownerPhone}
        onChangeText={value => {
          setOwnerPhone(value.replace(/\D/g, '').slice(0, 10));
          setError('');
        }}
        placeholder="10 अंकों का नंबर"
        keyboardType="number-pad"
        maxLength={10}
        containerStyle={styles.gap}
      />
      <Field
        label="पासवर्ड"
        value={password}
        onChangeText={value => {
          setPassword(value);
          setError('');
        }}
        placeholder="पासवर्ड"
        secureTextEntry
      />

      {infoBox}
      {errorBox}

      <PrimaryButton
        label="ओनर के रूप में लॉगिन"
        onPress={handleOwnerSignIn}
        icon={<Lock size={16} color={colors.white} />}
        style={styles.gap}
      />

      <Pressable onPress={openForgotPassword} style={styles.forgotLink}>
        <KeyRound size={13} color={colors.brandMid} />
        <Text style={styles.forgotLinkText}>पासवर्ड भूल गए?</Text>
      </Pressable>
    </View>
  );

  const forgotCard = (
    <View style={styles.card}>
      <Pressable onPress={closeForgotPassword} style={styles.backLink}>
        <ChevronLeft size={14} color={colors.brandMid} />
        <Text style={styles.backLinkText}>लॉगिन पर वापस</Text>
      </Pressable>

      <View style={styles.cardHead}>
        <View style={styles.cardIcon}>
          <KeyRound size={18} color={colors.brand} />
        </View>
        <View style={styles.flex}>
          <Text style={styles.cardTitle}>पासवर्ड भूल गए?</Text>
          <Text style={styles.cardCaption}>
            रजिस्टर्ड ओनर नंबर डालकर नया पासवर्ड बनाइए
          </Text>
        </View>
      </View>

      <Field
        label="रजिस्टर्ड ओनर नंबर"
        value={resetPhone}
        onChangeText={value => {
          setResetPhone(value.replace(/\D/g, '').slice(0, 10));
          setError('');
        }}
        placeholder="10 अंकों का नंबर"
        keyboardType="number-pad"
        maxLength={10}
      />
      <Field
        label="नया पासवर्ड"
        value={newPassword}
        onChangeText={value => {
          setNewPassword(value);
          setError('');
        }}
        placeholder="कम से कम 4 अक्षर"
        secureTextEntry
      />
      <Field
        label="नया पासवर्ड दोबारा"
        value={confirmNewPassword}
        onChangeText={value => {
          setConfirmNewPassword(value);
          setError('');
        }}
        placeholder="नया पासवर्ड दोहराइए"
        secureTextEntry
      />

      {errorBox}

      <PrimaryButton
        label="नया पासवर्ड सेव करें"
        onPress={handleResetPassword}
        icon={<KeyRound size={16} color={colors.white} />}
      />

      <Text style={styles.note}>
        सुरक्षा के लिए सिर्फ ओनर का रजिस्टर्ड नंबर ही काम करेगा।
      </Text>
    </View>
  );

  const setupCard = (
    <View style={styles.card}>
      <View style={styles.cardHead}>
        <View style={styles.cardIcon}>
          <ShieldCheck size={18} color={colors.brand} />
        </View>
        <View style={styles.flex}>
          <Text style={styles.cardTitle}>ओनर अकाउंट बनाइए</Text>
          <Text style={styles.cardCaption}>
            सिर्फ पहली बार · पासवर्ड आप खुद तय करेंगे
          </Text>
        </View>
      </View>

      <Field
        label="ओनर का नाम"
        value={ownerName}
        onChangeText={value => {
          setOwnerName(value);
          setError('');
        }}
        placeholder="जैसे: जयवीर गुप्ता"
        autoCapitalize="words"
      />
      <Field
        label="मोबाइल नंबर"
        value={ownerPhone}
        onChangeText={value => {
          setOwnerPhone(value.replace(/\D/g, '').slice(0, 10));
          setError('');
        }}
        placeholder="10 अंकों का नंबर"
        keyboardType="number-pad"
        maxLength={10}
      />
      <Field
        label="पासवर्ड"
        value={password}
        onChangeText={value => {
          setPassword(value);
          setError('');
        }}
        placeholder="कम से कम 4 अक्षर"
        secureTextEntry
        hint="यही पासवर्ड ओनर लॉगिन में काम आएगा।"
      />
      <Field
        label="पासवर्ड दोबारा"
        value={confirmPassword}
        onChangeText={value => {
          setConfirmPassword(value);
          setError('');
        }}
        placeholder="पासवर्ड दोहराइए"
        secureTextEntry
      />

      {errorBox}

      <PrimaryButton
        label="अकाउंट बनाकर शुरू करें"
        onPress={handleSetup}
        icon={<ShieldCheck size={17} color={colors.white} />}
      />

      <Text style={styles.note}>
        यह सेटअप सिर्फ एक बार होगा। अगली बार सीधे ओनर लॉगिन खुलेगा। स्टाफ बाद
        में स्टाफ टैब से जुड़ेंगे।
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <LiquidBackground />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.hero}>
            <View style={styles.logo}>
              <Store size={26} color={colors.white} />
            </View>
            <Text style={styles.appName}>JVG SmartTech Suvidha</Text>
            <Text style={styles.appCaption}>
              किराना, इलेक्ट्रॉनिक्स और बैंकिंग सेवा की दुकान
            </Text>
          </View>

          <View style={styles.modeRow}>
            <Pressable
              onPress={() => switchMode('owner')}
              style={[styles.modeButton, mode === 'owner' && styles.modeActive]}
            >
              <UserCog
                size={15}
                color={mode === 'owner' ? colors.white : colors.brand}
              />
              <Text style={[styles.modeText, mode === 'owner' && styles.modeTextActive]}>
                {hasOwner ? 'ओनर लॉगिन' : 'पहली बार सेटअप'}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => switchMode('staff')}
              style={[styles.modeButton, mode === 'staff' && styles.modeActive]}
            >
              <Users
                size={15}
                color={mode === 'staff' ? colors.white : colors.brand}
              />
              <Text style={[styles.modeText, mode === 'staff' && styles.modeTextActive]}>
                स्टाफ
              </Text>
            </Pressable>
          </View>

          {mode === 'staff'
            ? staffCard
            : !hasOwner
              ? setupCard
              : forgotOpen
                ? forgotCard
                : ownerSignInCard}

          <View style={styles.footer}>
            <User size={13} color={colors.muted} />
            <Text style={styles.footerText}>
              लॉगिन और दुकान का डेटा सिर्फ इसी मोबाइल में सुरक्षित रहता है।
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 28,
    gap: 20,
  },
  hero: {
    alignItems: 'center',
    gap: 6,
  },
  logo: {
    width: 62,
    height: 62,
    borderRadius: 22,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
    ...shadow,
  },
  appName: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.ink,
    letterSpacing: -0.4,
    textAlign: 'center',
  },
  appCaption: {
    fontSize: 12,
    color: colors.muted,
    textAlign: 'center',
  },
  card: {
    backgroundColor: glass.fill,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: glass.border,
    padding: 18,
    gap: 13,
    ...shadow,
  },
  cardHead: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  cardIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: glass.fillStrong,
    borderWidth: 1,
    borderColor: glass.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.ink,
  },
  cardCaption: {
    fontSize: 11.5,
    color: colors.muted,
    marginTop: 1,
  },
  modeRow: {
    flexDirection: 'row',
    backgroundColor: glass.fillSoft,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: 999,
    padding: 4,
    gap: 4,
  },
  modeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 999,
  },
  modeActive: {
    backgroundColor: colors.brand,
  },
  modeText: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.brand,
  },
  modeTextActive: {
    color: colors.white,
  },
  gap: {
    marginTop: 2,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(251, 233, 231, 0.9)',
    borderRadius: 10,
    padding: 10,
  },
  errorText: {
    flex: 1,
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.danger,
  },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(226, 236, 229, 0.9)',
    borderRadius: 10,
    padding: 10,
  },
  infoText: {
    flex: 1,
    fontSize: 11.5,
    fontWeight: '600',
    color: colors.brandMid,
  },
  forgotLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingVertical: 2,
  },
  forgotLinkText: {
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.brandMid,
  },
  backLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    alignSelf: 'flex-start',
  },
  backLinkText: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.brandMid,
  },
  note: {
    fontSize: 10.5,
    color: colors.muted,
    lineHeight: 16,
    textAlign: 'center',
  },
  staffHint: {
    gap: 8,
    backgroundColor: glass.fillSoft,
    borderWidth: 1,
    borderColor: glass.border,
    borderRadius: radius.md,
    padding: 12,
  },
  staffHintTitle: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.muted,
    letterSpacing: 0.2,
  },
  staffRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  staffAvatar: {
    width: 26,
    height: 26,
    borderRadius: 9,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  staffAvatarText: {
    fontSize: 9.5,
    fontWeight: '800',
    color: colors.brand,
  },
  staffName: {
    flex: 1,
    fontSize: 12,
    fontWeight: '700',
    color: colors.ink,
  },
  staffPhoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  staffPhone: {
    fontSize: 10.5,
    fontWeight: '600',
    color: colors.muted,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 8,
  },
  footerText: {
    flex: 1,
    fontSize: 10,
    color: colors.muted,
    lineHeight: 15,
  },
});
