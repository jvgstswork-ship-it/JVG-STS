export const colors = {
  bg: '#f5f3ec',
  card: '#ffffff',
  ink: '#14251d',
  muted: '#708077',
  soft: '#9aa79f',
  line: '#e7e2d6',
  brand: '#12372a',
  brandMid: '#1d5440',
  brandSoft: '#e2ece5',
  accent: '#e6a23c',
  accentSoft: '#fbf1de',
  danger: '#b23b32',
  dangerSoft: '#fbe9e7',
  info: '#2f6f8f',
  infoSoft: '#e7f1f6',
  white: '#ffffff',
};

export const radius = {
  sm: 10,
  md: 14,
  lg: 20,
  xl: 26,
};

export const shadow = {
  shadowColor: '#0d2119',
  shadowOffset: { width: 0, height: 10 },
  shadowOpacity: 0.08,
  shadowRadius: 22,
  elevation: 5,
};

export const glass = {
  fill: 'rgba(255, 255, 255, 0.55)',
  fillStrong: 'rgba(255, 255, 255, 0.78)',
  fillSoft: 'rgba(255, 255, 255, 0.38)',
  border: 'rgba(255, 255, 255, 0.85)',
  line: 'rgba(18, 55, 42, 0.08)',
  overlay: 'rgba(255, 255, 255, 0.72)',
  input: 'rgba(255, 255, 255, 0.7)',
};

export const categories = [
  'किराना',
  'डेयरी',
  'स्नैक्स',
  'घरेलू',
  'व्यक्तिगत देखभाल',
  'टीवी',
  'फ्रिज',
  'वॉशिंग मशीन',
  'AC',
  'फैन',
  'स्माल एप्लायंसेज',
  'मोबाइल एक्सेसरीज़',
  'बैंकिंग सेवा',
  'अन्य',
];

export const categoryTone: Record<string, { bg: string; text: string }> = {
  'किराना': { bg: '#fbf0da', text: '#8a5a12' },
  'डेयरी': { bg: '#eef4fb', text: '#35698f' },
  'स्नैक्स': { bg: '#fbe6e9', text: '#99404e' },
  'घरेलू': { bg: '#e3f0ee', text: '#2c6b62' },
  'व्यक्तिगत देखभाल': { bg: '#f0eaf7', text: '#6a4b8a' },
  'टीवी': { bg: '#e6eef6', text: '#2f5f85' },
  'फ्रिज': { bg: '#e3f0ee', text: '#2c6b62' },
  'वॉशिंग मशीन': { bg: '#efe8f6', text: '#6a4b8a' },
  'AC': { bg: '#e6f4f8', text: '#236b80' },
  'फैन': { bg: '#fbf0da', text: '#8a5a12' },
  'स्माल एप्लायंसेज': { bg: '#fbe6e9', text: '#99404e' },
  'मोबाइल एक्सेसरीज़': { bg: '#e2ece5', text: '#1d5440' },
  'बैंकिंग सेवा': { bg: '#e8ecf6', text: '#3a4d87' },
  'अन्य': { bg: '#efeee9', text: '#6d7069' },
};
