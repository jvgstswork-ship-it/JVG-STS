export const shop = {
  name: 'JVG SmartTech Suvidha',
  tagline: 'मोबाइल एक्सेसरीज़ और बैंकिंग सेवा',
  phone: '98765 43210',
  address: 'मेन मार्केट, आपका शहर',
  upiId: 'jvgsmarttech@upi',
  upiName: 'JVG SmartTech',
};
