import type { BadgeTone } from '@/components/ui';
import type { PaymentMode } from '@/store/shop';

export const paymentOptions: { mode: PaymentMode; label: string; caption: string }[] = [
  { mode: 'cash', label: 'नकद', caption: 'Cash' },
  { mode: 'upi', label: 'UPI', caption: 'Online' },
  { mode: 'udhaar', label: 'उधार', caption: 'Credit' },
];

export function paymentMeta(
  mode: PaymentMode,
  settled: boolean,
): { label: string; tone: BadgeTone } {
  if (mode === 'cash') return { label: 'नकद', tone: 'brand' };
  if (mode === 'upi') return { label: 'UPI', tone: 'info' };
  return settled
    ? { label: 'उधार चुकता', tone: 'muted' }
    : { label: 'उधार बाकी', tone: 'danger' };
}
