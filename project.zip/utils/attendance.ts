import type { AttendanceMap } from '@/store/shop';

export function dateKey(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function monthStats(
  records: Record<string, boolean> | undefined,
  date: Date = new Date(),
): { present: number; absent: number; marked: number } {
  let present = 0;
  let absent = 0;

  Object.entries(records ?? {}).forEach(([key, value]) => {
    const [year, month] = key.split('-').map(Number);
    if (year === date.getFullYear() && month === date.getMonth() + 1) {
      if (value) present += 1;
      else absent += 1;
    }
  });

  return { present, absent, marked: present + absent };
}

export type MonthCell = {
  day: number;
  key: string;
  weekday: number;
  value: boolean | null;
  isToday: boolean;
};

export function monthCells(
  records: Record<string, boolean> | undefined,
  date: Date = new Date(),
): MonthCell[] {
  const year = date.getFullYear();
  const month = date.getMonth();
  const days = new Date(year, month + 1, 0).getDate();
  const todayKey = dateKey();

  return Array.from({ length: days }, (_, index) => {
    const day = index + 1;
    const cellDate = new Date(year, month, day);
    const key = dateKey(cellDate);
    return {
      day,
      key,
      weekday: cellDate.getDay(),
      value: records?.[key] ?? null,
      isToday: key === todayKey,
    };
  });
}
