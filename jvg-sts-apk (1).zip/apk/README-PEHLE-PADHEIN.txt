JVG STS - APK banane ka tareeka (free, bina coding)
=====================================================
Ye project GitHub ki free service se apne aap APK bana deta hai.
Computer ya cyber cafe se karna sabse aasan hai.

1) github.com par free account banayein (agar nahi hai).
2) Naya repository banayein: New repository -> naam jvg-sts -> Create.
3) Is zip ko khol lein. "uploading an existing file" par click karke
   zip ke andar ki SAARI files aur folders (www, assets, keystore,
   package.json, capacitor.config.json) upload karein -> Commit.
4) Hidden folder ".github" upload nahi hota to ye karein:
   Add file -> Create new file -> naam mein likhein:
   .github/workflows/build-apk.yml
   Phir is zip ki .github/workflows/build-apk.yml ka poora text paste
   karke Commit karein.
5) Repository ke "Actions" tab mein "Build APK" khulega aur apne aap
   chalega (5-8 minute). Hara tick aane ka intezaar karein.
6) Us run par click karein -> neeche "Artifacts" mein JVG-STS-APK
   download karein -> zip kholne par app-debug.apk milegi.
7) APK ko phone mein bhejein aur install karein
   (Settings mein "Unknown sources / Is source se install" allow karna hoga).

Dhyan rakhein
- Data phone mein hi save hota hai. History tab ke CSV se backup lete rahein.
- Naya APK purane par install ho jata hai aur data bana rehta hai
  (keystore folder isi liye hai, use mat hatayein).
- Ye debug APK hai, khud ke use ke liye theek hai. Play Store ke liye
  alag signed release banani padegi.
- Receipt ka "Share" button WhatsApp aadi par bhejne ke liye hai.
